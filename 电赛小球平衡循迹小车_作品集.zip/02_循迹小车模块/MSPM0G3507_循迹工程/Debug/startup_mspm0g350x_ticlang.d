# FIXED

startup_mspm0g350x_ticlang.o: \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/msp.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/DeviceFamily.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/m0p/mspm0g350x.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_adc12.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_aes.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_comp.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_crc.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_dac12.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_dma.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_flashctl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_gpio.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_gptimer.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_i2c.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_iomux.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_mathacl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_mcan.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_oa.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_rtc.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_spi.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_trng.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_uart.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_vref.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_wuc.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_wwdt.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/msp.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/DeviceFamily.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/m0p/mspm0g350x.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_adc12.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_aes.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_comp.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_crc.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_dac12.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_dma.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_flashctl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_gpio.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_gptimer.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_i2c.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_iomux.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_mathacl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_mcan.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_oa.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_rtc.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_spi.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_trng.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_uart.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_vref.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_wuc.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_wwdt.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h:
