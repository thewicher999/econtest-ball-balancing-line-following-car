# FIXED

four_line.o: ../four_line.c ../four_line.h ../motor.h ../ssd1306.h \
 syscfg/ti_msp_dl_config.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/msp.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/DeviceFamily.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/m0p/mspm0g350x.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_adc12.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_aes.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_comp.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_crc.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_dac12.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_dma.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_flashctl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_gpio.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_gptimer.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_i2c.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_iomux.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_mathacl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_mcan.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_oa.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_rtc.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_spi.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_trng.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_uart.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_vref.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_wuc.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_wwdt.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/driverlib.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_adc12.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_common.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_factoryregion.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_core.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_aes.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_aesadv.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_comp.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_crc.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_crcp.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_dac12.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_dma.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_flashctl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_sysctl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_gpamp.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_gpio.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_i2c.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_iwdt.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_lfss.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_keystorectl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_lcd.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_mathacl.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_mcan.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_opa.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_rtc.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_rtc_common.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_rtc_a.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_rtc_b.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_scratchpad.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_spi.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_tamperio.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_timera.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_timer.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_timerg.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_trng.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_uart_extend.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_uart.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_uart_main.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_vref.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_wwdt.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_interrupt.h \
 D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_systick.h
../four_line.h:
../motor.h:
../ssd1306.h:
syscfg/ti_msp_dl_config.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/msp.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/DeviceFamily.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/m0p/mspm0g350x.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_adc12.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_aes.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_comp.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_crc.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_dac12.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_dma.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_flashctl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_gpio.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_gptimer.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_i2c.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_iomux.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_mathacl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_mcan.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_oa.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_rtc.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_spi.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_trng.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_uart.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_vref.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_wuc.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/hw_wwdt.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/driverlib.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_adc12.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_common.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_factoryregion.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_core.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_aes.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_aesadv.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_comp.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_crc.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_crcp.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_dac12.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_dma.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_flashctl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_sysctl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_gpamp.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_gpio.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_i2c.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_iwdt.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_lfss.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_keystorectl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_lcd.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_mathacl.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_mcan.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_opa.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_rtc.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_rtc_common.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_rtc_a.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_rtc_b.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_scratchpad.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_spi.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_tamperio.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_timera.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_timer.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_timerg.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_trng.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_uart_extend.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_uart.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_uart_main.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_vref.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/dl_wwdt.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_interrupt.h:
D:/dpjxxstudy/ti/mspm0_sdk_2_05_01_00/source/ti/driverlib/m0p/dl_systick.h:
