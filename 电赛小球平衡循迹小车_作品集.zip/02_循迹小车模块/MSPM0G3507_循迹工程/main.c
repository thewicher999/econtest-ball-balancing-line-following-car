/*
 * Modified 2026-07-27:
 * MPU6050 and dedicated right-angle control are not used.
 * The car uses straight/curve tracking and SEARCH_SPEED after line loss.
 */
#include "ti_msp_dl_config.h"
#include "four_line.h"
#include "motor.h"
#include "ssd1306.h"

#define CONTROL_PERIOD_CYCLES 32000U
#define S2_DEBOUNCE_MS 30U
#define S2_LONG_PRESS_MS 800U
#define MODE_SWITCH_FEEDBACK_MS 500U
#define DISPLAY_PERIOD_MS 100U
#define FINISH_SENSOR_COUNT 4U
#define FINISH_CONFIRM_COUNT 1U

typedef enum {
    S2_ACTION_NONE = 0,
    S2_ACTION_SHORT,
    S2_ACTION_LONG
} S2Action;

static volatile uint32_t elapsedMs;
static uint32_t modeFeedbackUntilMs;

void SysTick_Handler(void)
{
    elapsedMs++;
}

static uint8_t s2Pressed(void)
{
    return (DL_GPIO_readPins(S2_BUTTON_PORT, S2_BUTTON_S2_PIN) == 0U);
}

static uint8_t countActiveSensors(uint8_t mask)
{
    uint8_t count = 0U;

    while (mask != 0U) {
        count += (uint8_t) (mask & 1U);
        mask >>= 1U;
    }
    return count;
}

static void showStatus(const char *title, uint32_t timeMs)
{
    char text[] = "00.000 s";
    uint32_t seconds = timeMs / 1000U;
    uint32_t millis = timeMs % 1000U;

    if (seconds > 99U) seconds = 99U;
    text[0] = (char) ('0' + seconds / 10U);
    text[1] = (char) ('0' + seconds % 10U);
    text[3] = (char) ('0' + millis / 100U);
    text[4] = (char) ('0' + (millis / 10U) % 10U);
    text[5] = (char) ('0' + millis % 10U);
    SSD1306_clear();
    SSD1306_drawString(0U, 0U, title);
    SSD1306_drawString(0U, 16U, text);
    SSD1306_drawString(0U, 32U,
                       (FourLine_getMode() == FOUR_LINE_MODE_STABLE) ?
                           "MODE: STABLE" : "MODE: FAST");
}

static void toggleLineMode(uint32_t displayTimeMs)
{
    if (FourLine_getMode() == FOUR_LINE_MODE_FAST) {
        FourLine_setMode(FOUR_LINE_MODE_STABLE);
    } else {
        FourLine_setMode(FOUR_LINE_MODE_FAST);
    }
    modeFeedbackUntilMs = elapsedMs + MODE_SWITCH_FEEDBACK_MS;
    showStatus("MODE CHANGED", displayTimeMs);
}

static uint8_t modeFeedbackActive(void)
{
    return ((int32_t) (modeFeedbackUntilMs - elapsedMs) > 0);
}

static S2Action readS2Action(void)
{
    uint32_t pressStartMs;
    uint8_t longPress = 0U;

    if (s2Pressed() == 0U) return S2_ACTION_NONE;

    Motor_stop();
    pressStartMs = elapsedMs;
    delay_cycles(CPUCLK_FREQ / 1000U * S2_DEBOUNCE_MS);
    if (s2Pressed() == 0U) return S2_ACTION_NONE;

    /* One complete press produces exactly one short or long action. */
    for (;;) {
        while (s2Pressed() != 0U) {
            Motor_stop();
            if ((elapsedMs - pressStartMs) >= S2_LONG_PRESS_MS) {
                longPress = 1U;
            }
        }
        delay_cycles(CPUCLK_FREQ / 1000U * S2_DEBOUNCE_MS);
        if (s2Pressed() == 0U) break;
    }
    return (longPress != 0U) ? S2_ACTION_LONG : S2_ACTION_SHORT;
}

static void showWaitForStart(void)
{
    SSD1306_clear();
    SSD1306_drawString(0U, 0U, "PRESS START");
    SSD1306_drawString(0U, 16U, "S2 SHORT: GO");
    SSD1306_drawString(0U, 32U,
                       (FourLine_getMode() == FOUR_LINE_MODE_STABLE) ?
                           "MODE: STABLE" : "MODE: FAST");
    SSD1306_drawString(0U, 48U, "S2 HOLD: MODE");
}

static void waitForStart(void)
{
    Motor_stop();
    showWaitForStart();

    for (;;) {
        S2Action action = readS2Action();

        if (action == S2_ACTION_SHORT) return;
        if (action == S2_ACTION_LONG) {
            toggleLineMode(0U);
            while (modeFeedbackActive() != 0U) {
                Motor_stop();
            }
            showWaitForStart();
        }
    }
}

int main(void)



{
    SYSCFG_DL_init();
    SSD1306_init();
    FourLine_init();
    Motor_stop();
    FourLine_setDisplayEnabled(0U);
    DL_SYSTICK_config(CPUCLK_FREQ / 1000U);

    waitForStart();
    elapsedMs = 0U;

    uint32_t lastDisplayMs = 0U;
    uint8_t finishArmed = 0U;
    uint8_t finishConfirm = 0U;
    modeFeedbackUntilMs = 0U;

    showStatus("RUNNING", elapsedMs);

    while (1) {
        if (readS2Action() == S2_ACTION_LONG) {
            toggleLineMode(elapsedMs);
        }

        FourLine_update();

        if (FourLine_getMode() == FOUR_LINE_MODE_FAST) {
            uint8_t activeCount = countActiveSensors(FourLine_getLastMask());
            if (finishArmed == 0U) {
                if (activeCount <= 3U) finishArmed = 1U;
            } else if (activeCount >= FINISH_SENSOR_COUNT) {
                if (finishConfirm < FINISH_CONFIRM_COUNT) finishConfirm++;
            } else {
                finishConfirm = 0U;
            }
        } else {
            finishConfirm = 0U;
        }

        if ((elapsedMs - lastDisplayMs) >= DISPLAY_PERIOD_MS) {
            lastDisplayMs = elapsedMs;
            showStatus(modeFeedbackActive() ? "MODE CHANGED" : "RUNNING",
                       elapsedMs);
        }

        if ((FourLine_getMode() == FOUR_LINE_MODE_FAST) &&
            (finishConfirm >= FINISH_CONFIRM_COUNT)) {
            uint32_t finalTimeMs = elapsedMs;
            Motor_stop();
            showStatus("FINISHED", finalTimeMs);
            while (1) {
                Motor_stop();
            }
        }
        delay_cycles(CONTROL_PERIOD_CYCLES);
    }
}
