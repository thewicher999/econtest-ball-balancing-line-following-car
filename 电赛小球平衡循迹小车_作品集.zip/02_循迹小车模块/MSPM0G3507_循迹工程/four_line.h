#ifndef FOUR_LINE_H
#define FOUR_LINE_H

#include <stdint.h>

typedef enum {
    FOUR_LINE_MODE_FAST = 0,
    FOUR_LINE_MODE_STABLE = 1
} FourLineMode;

void FourLine_init(void);
void FourLine_update(void);
uint8_t FourLine_getLastMask(void);
void FourLine_setDisplayEnabled(uint8_t enabled);
void FourLine_setMode(FourLineMode mode);
FourLineMode FourLine_getMode(void);

#endif
