#ifndef SSD1306_H
#define SSD1306_H

#include <stdint.h>

void SSD1306_init(void);
void SSD1306_clear(void);
void SSD1306_drawString(uint8_t x, uint8_t y, const char *text);

#endif
