#include "ssd1306.h"

#include <stdbool.h>
#include <stddef.h>

#include "ti_msp_dl_config.h"

#define SSD1306_ADDRESS 0x3CU
#define SSD1306_WIDTH 128U
#define SSD1306_PAGES 8U
#define I2C_TIMEOUT 1000000U

static bool i2cWrite(const uint8_t *data, uint8_t length)
{
    uint32_t timeout = I2C_TIMEOUT;

    while (!(DL_I2C_getControllerStatus(I2C_OLED_INST) &
             DL_I2C_CONTROLLER_STATUS_IDLE)) {
        if (--timeout == 0U) {
            return false;
        }
    }

    DL_I2C_flushControllerTXFIFO(I2C_OLED_INST);
    DL_I2C_fillControllerTXFIFO(I2C_OLED_INST, data, length);
    DL_I2C_startControllerTransfer(I2C_OLED_INST, SSD1306_ADDRESS,
        DL_I2C_CONTROLLER_DIRECTION_TX, length);

    timeout = I2C_TIMEOUT;
    while (DL_I2C_getControllerStatus(I2C_OLED_INST) &
           DL_I2C_CONTROLLER_STATUS_BUSY_BUS) {
        if (--timeout == 0U) {
            return false;
        }
    }

    return !(DL_I2C_getControllerStatus(I2C_OLED_INST) &
             DL_I2C_CONTROLLER_STATUS_ERROR);
}

static void writeCommand(uint8_t command)
{
    const uint8_t packet[2] = {0x00U, command};
    (void) i2cWrite(packet, sizeof(packet));
}

static void writeData(const uint8_t *data, uint8_t length)
{
    uint8_t packet[8];

    while (length > 0U) {
        uint8_t chunk = (length > 7U) ? 7U : length;
        packet[0] = 0x40U;
        for (uint8_t i = 0U; i < chunk; i++) {
            packet[i + 1U] = data[i];
        }
        (void) i2cWrite(packet, (uint8_t) (chunk + 1U));
        data += chunk;
        length -= chunk;
    }
}

static const uint8_t *glyph(char c)
{
    static const uint8_t blank[5] = {0, 0, 0, 0, 0};
    static const uint8_t font[][5] = {
        {0x3E,0x51,0x49,0x45,0x3E}, /* 0 */
        {0x00,0x42,0x7F,0x40,0x00}, /* 1 */
        {0x42,0x61,0x51,0x49,0x46}, /* 2 */
        {0x21,0x41,0x45,0x4B,0x31}, /* 3 */
        {0x18,0x14,0x12,0x7F,0x10}, /* 4 */
        {0x27,0x45,0x45,0x45,0x39}, /* 5 */
        {0x3C,0x4A,0x49,0x49,0x30}, /* 6 */
        {0x01,0x71,0x09,0x05,0x03}, /* 7 */
        {0x36,0x49,0x49,0x49,0x36}, /* 8 */
        {0x06,0x49,0x49,0x29,0x1E}, /* 9 */
        {0x7E,0x11,0x11,0x11,0x7E}, /* A */
        {0x7F,0x49,0x49,0x49,0x36}, /* B */
        {0x3E,0x41,0x41,0x41,0x22}, /* C */
        {0x7F,0x41,0x41,0x22,0x1C}, /* D */
        {0x7F,0x49,0x49,0x49,0x41}, /* E */
        {0x7F,0x09,0x09,0x09,0x01}, /* F */
        {0x3E,0x41,0x49,0x49,0x7A}, /* G */
        {0x7F,0x08,0x08,0x08,0x7F}, /* H */
        {0x00,0x41,0x7F,0x41,0x00}, /* I */
        {0x20,0x40,0x41,0x3F,0x01}, /* J */
        {0x7F,0x08,0x14,0x22,0x41}, /* K */
        {0x7F,0x40,0x40,0x40,0x40}, /* L */
        {0x7F,0x02,0x0C,0x02,0x7F}, /* M */
        {0x7F,0x04,0x08,0x10,0x7F}, /* N */
        {0x3E,0x41,0x41,0x41,0x3E}, /* O */
        {0x7F,0x09,0x09,0x09,0x06}, /* P */
        {0x3E,0x41,0x51,0x21,0x5E}, /* Q */
        {0x7F,0x09,0x19,0x29,0x46}, /* R */
        {0x46,0x49,0x49,0x49,0x31}, /* S */
        {0x01,0x01,0x7F,0x01,0x01}, /* T */
        {0x3F,0x40,0x40,0x40,0x3F}, /* U */
        {0x1F,0x20,0x40,0x20,0x1F}, /* V */
        {0x7F,0x20,0x18,0x20,0x7F}, /* W */
        {0x63,0x14,0x08,0x14,0x63}, /* X */
        {0x03,0x04,0x78,0x04,0x03}, /* Y */
        {0x61,0x51,0x49,0x45,0x43}  /* Z */
    };
    static const uint8_t period[5] = {0x00,0x60,0x60,0x00,0x00};
    static const uint8_t colon[5] = {0x00,0x36,0x36,0x00,0x00};
    static const uint8_t hyphen[5] = {0x08,0x08,0x08,0x08,0x08};
    static const uint8_t greater[5] = {0x00,0x41,0x22,0x14,0x08};

    if ((c >= 'a') && (c <= 'z')) c = (char) (c - 'a' + 'A');
    if ((c >= '0') && (c <= '9')) return font[c - '0'];
    if ((c >= 'A') && (c <= 'Z')) return font[10 + c - 'A'];
    if (c == '.') return period;
    if (c == ':') return colon;
    if (c == '-') return hyphen;
    if (c == '>') return greater;
    return blank;
}

static void setCursor(uint8_t x, uint8_t page)
{
    writeCommand((uint8_t) (0xB0U | page));
    writeCommand((uint8_t) (0x00U | (x & 0x0FU)));
    writeCommand((uint8_t) (0x10U | (x >> 4U)));
}

void SSD1306_init(void)
{
    static const uint8_t commands[] = {
        0xAE, 0xD5, 0x80, 0xA8, 0x3F, 0xD3, 0x00, 0x40,
        0x8D, 0x14, 0x20, 0x02, 0xA1, 0xC8, 0xDA, 0x12,
        0x81, 0xCF, 0xD9, 0xF1, 0xDB, 0x40, 0xA4, 0xA6,
        0xAF
    };

    delay_cycles(3200000U);
    for (size_t i = 0U; i < sizeof(commands); i++) {
        writeCommand(commands[i]);
    }
}

void SSD1306_clear(void)
{
    static const uint8_t zeros[7] = {0, 0, 0, 0, 0, 0, 0};

    for (uint8_t page = 0U; page < SSD1306_PAGES; page++) {
        setCursor(0U, page);
        uint8_t remaining = SSD1306_WIDTH;
        while (remaining > 0U) {
            uint8_t chunk = (remaining > sizeof(zeros)) ? sizeof(zeros) : remaining;
            writeData(zeros, chunk);
            remaining -= chunk;
        }
    }
}

void SSD1306_drawString(uint8_t x, uint8_t y, const char *text)
{
    uint8_t page = y / 8U;
    uint8_t column = x;

    while ((*text != '\0') && (column + 6U <= SSD1306_WIDTH)) {
        uint8_t character[6];
        const uint8_t *font = glyph(*text++);
        for (uint8_t i = 0U; i < 5U; i++) {
            character[i] = font[i];
        }
        character[5] = 0U;
        setCursor(column, page);
        writeData(character, sizeof(character));
        column += sizeof(character);
    }
}
