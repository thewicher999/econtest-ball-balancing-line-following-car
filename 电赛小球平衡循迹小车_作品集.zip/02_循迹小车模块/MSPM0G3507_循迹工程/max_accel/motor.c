#include "motor.h"

#include "ti_msp_dl_config.h"

#define MOTOR_PWM_PERIOD 1600U
#define MOTOR_MAX_SPEED 100

/* 将速度限制在允许范围内，负数表示反转。 */
static int16_t clampSpeed(int16_t speed)
{
    if (speed > MOTOR_MAX_SPEED) return MOTOR_MAX_SPEED;
    if (speed < -MOTOR_MAX_SPEED) return -MOTOR_MAX_SPEED;
    return speed;
}

/* 根据速度正负设置 L298N 四个方向引脚。 */
static void setDirection(int16_t leftSpeed, int16_t rightSpeed)
{
    uint32_t allPins = CAR_GPIO_MOTOR_IN1_PIN | CAR_GPIO_MOTOR_IN2_PIN |
                       CAR_GPIO_MOTOR_IN3_PIN | CAR_GPIO_MOTOR_IN4_PIN;
    uint32_t setPins = 0U;

    if (leftSpeed > 0) setPins |= CAR_GPIO_MOTOR_IN2_PIN;
    else if (leftSpeed < 0) setPins |= CAR_GPIO_MOTOR_IN1_PIN;

    if (rightSpeed > 0) setPins |= CAR_GPIO_MOTOR_IN3_PIN;
    else if (rightSpeed < 0) setPins |= CAR_GPIO_MOTOR_IN4_PIN;

    DL_GPIO_clearPins(CAR_GPIO_PORT, allPins);
    DL_GPIO_setPins(CAR_GPIO_PORT, setPins);
}

void Motor_init(void)
{
    DL_TimerG_startCounter(MOTOR_PWM_INST);
    Motor_stop();
}

void Motor_set(int16_t leftSpeed, int16_t rightSpeed)
{
    uint16_t leftDuty;
    uint16_t rightDuty;
    uint16_t leftCompare;
    uint16_t rightCompare;

    leftSpeed = clampSpeed(leftSpeed);
    rightSpeed = clampSpeed(rightSpeed);
    setDirection(leftSpeed, rightSpeed);

    leftDuty = (uint16_t) ((leftSpeed < 0) ? -leftSpeed : leftSpeed);
    rightDuty = (uint16_t) ((rightSpeed < 0) ? -rightSpeed : rightSpeed);
    leftCompare = MOTOR_PWM_PERIOD -
        (MOTOR_PWM_PERIOD * leftDuty / 100U);
    rightCompare = MOTOR_PWM_PERIOD -
        (MOTOR_PWM_PERIOD * rightDuty / 100U);

    DL_TimerG_setCaptureCompareValue(
        MOTOR_PWM_INST, leftCompare, GPIO_MOTOR_PWM_C0_IDX);
    DL_TimerG_setCaptureCompareValue(
        MOTOR_PWM_INST, rightCompare, GPIO_MOTOR_PWM_C1_IDX);
}

void Motor_stop(void)
{
    Motor_set(0, 0);
}
