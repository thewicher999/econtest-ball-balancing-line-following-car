#ifndef MOTOR_H
#define MOTOR_H

#include <stdint.h>

void Motor_init(void);
void Motor_set(int16_t leftSpeed, int16_t rightSpeed);
void Motor_stop(void);

#endif
