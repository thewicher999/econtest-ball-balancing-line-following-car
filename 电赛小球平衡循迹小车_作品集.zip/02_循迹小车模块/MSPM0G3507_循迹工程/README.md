# MSPM0G3507 SSD1306 Test

## 2026-07-31 S2 short/long-press update

- The onboard `S2 / PB21` button now performs both functions.
- Before start, short-press and release S2 to start line following.
- Long-press S2 for at least 800 ms and release to switch FAST/STABLE mode.
- During a run, long-press S2 switches mode; a short press does nothing.
- One complete press produces exactly one action after release.
- The motors remain stopped while S2 is held.
- `S2_LONG_PRESS_MS` and `S2_DEBOUNCE_MS` are at the top of `main.c`.
- S1/PA18 is no longer configured or read by this firmware.
- `MODE CHANGED` is shown for 500 ms after a successful switch.
- OLED line 3 shows the original elapsed time.
- OLED line 5 continuously shows `MODE: FAST` or `MODE: STABLE`.
- The included `Debug/mspm0g3507_empty_driverlib.out` was rebuilt after this update.

## Two line-following modes

- Power-on defaults to the tested FAST mode; long-press S2 can select STABLE before starting.
- Before starting, short-press S2 to run or long-press S2 to switch modes.
- S3 is the LaunchPad reset button. Pressing it restarts the program, so the brief `LINE MODE 000000` screen is normal and is not a mode switch.
- The elapsed time remains on OLED line 3, while the current mode is continuously shown on line 5.
- FAST mode keeps the original second-task discrete steering logic and values.
- STABLE mode uses an independent continuous PD controller, curve slowdown,
  motor-output slew limiting, and gentle lost-line recovery for tasks 4 and 5.
- Tune only the `STABLE_*` values at the top of `four_line.c`. Start with
  `STABLE_BASE_SPEED`, then `STABLE_KP_NUM`, and finally `STABLE_KD_NUM`.

## H problem lap timing and stop

- The original line-following speeds and steering thresholds are unchanged.
- The onboard S2 is `PB21`, active-low, with the internal pull-up resistor.
- S2 short press starts; S2 long press switches mode.
- After power-up, the car remains stopped and the OLED shows `PRESS START`.
- Short-press and release S2 to start line following and the millisecond timer.
- Finish detection is armed only after leaving the initial A stop line. The car
  stops when at least 6 of 8 sensors see black for 3 consecutive updates, then
  the OLED holds the final time.
- If the 5 cm stop line is missed, change `FINISH_SENSOR_COUNT` in `main.c` from
  `6U` to `5U`. If curves cause false stops, use `7U` or increase
  `FINISH_CONFIRM_COUNT`.

## Four-channel automatic line following (V8)

## Eight-channel YB-MYX05 wiring

The active firmware now reads the eight-channel analog multiplexer output and
keeps the existing four-region straight/curve steering logic.

- Sensor 5V -> LaunchPad 5V
- Sensor GND -> LaunchPad GND and L298N GND
- Sensor OUT -> PA25 (ADC0 channel 2)
- Sensor AD0 -> PB6
- Sensor AD1 -> PB7
- Sensor AD2 -> PB8

Do not connect the old four-channel X1-X4 wires. The sensor labels X1-X8 are
the optical channels and do not each require an MCU wire. If detection is
reversed, change `BLACK_IS_LOW`; if detection is unreliable, adjust
`LINE_THRESHOLD` in `four_line.c`.

The active firmware uses the YB-4W-BK four-channel digital tracing sensor.
Bluetooth and the old eight-channel analog sensor are not used.

- VCC -> 3.3 V
- GND -> GND (common with LaunchPad and L298N)
- X1 -> PB4 (left-center sensor)
- X2 -> PB6 (leftmost sensor)
- X3 -> PB7 (right-center sensor)
- X4 -> PB8 (rightmost sensor)

Physical sensor order from left to right is `X2, X1, X3, X4`.

The car starts tracking automatically after power-on. OLED `S:XXXX` shows
which sensors detect black. The default assumes black outputs low. If the bits
are reversed, change `BLACK_LEVEL` in `four_line.c` from `0U` to `1U`.

DriverLib and SysConfig test for displaying `thewicher999` on a 128x64
SSD1306 I2C OLED.

## Configuration

- Device: MSPM0G3507
- Package: LQFP-64 (PM)
- SDK: MSPM0 SDK 2.05.01.00
- Toolchain: TI Arm Clang
- Runtime: NoRTOS
- Debug connection: XDS110 (change it in CCS if your probe differs)
- I2C: I2C1 at 400 kHz
- SCL: PB2
- SDA: PB3
- OLED address: 0x3C

## Wiring

Connect power with both boards switched off:

| OLED | LP-MSPM0G3507 |
| --- | --- |
| GND | GND |
| VCC | 3V3 |
| SCL | PB2 |
| SDA | PB3 |

Use 3.3 V for this test. Most four-pin SSD1306 modules already include I2C
pull-up resistors. If yours does not, add 4.7 kohm pull-ups from SCL and SDA
to 3.3 V.

## Import into CCS

1. Open CCS and select **File > Import Project(s)**.
2. Browse to this directory and select `mspm0g3507_empty_driverlib.projectspec`.
3. Confirm CCS resolves `MSPM0-SDK` to `D:\\dpjxxstudy\\ti\\mspm0_sdk_2_05_01_00`.
4. Build the imported project. SysConfig generates `ti_msp_dl_config.c`,
   `ti_msp_dl_config.h`, the startup/linker configuration, and DriverLib links.

Generated files belong to the build directory and should not be edited manually.

## Temporary motor motion test

This package does not read the unplugged line sensor. At power-up it drives at
75 percent duty for three seconds, turns in place at 75 percent duty, then
stops permanently. The turn uses an open-loop 0.8 second estimate because the
chassis has no wheel encoder.
Adjust `TURN_CYCLES` in `line_car.c` if the measured rotation is short or long.

## JDY-31 Bluetooth remote

The active application uses UART0 at 9600 baud. Connect JDY-31 TXD to PA11
(MCU RX), RXD to PA10 (MCU TX), STATE to PB4, VCC to 3.3 V, and GND to the
common ground. EN is unused. The phone app must use HEX mode: `01` forward, `02`
backward, `03` left, `04` right, and `00` stop. Configure every direction
button to send `00` when released so the car stops immediately.

For diagnosis, every received byte is echoed back to the phone. The firmware
also accepts text characters `1`, `2`, `3`, `4`, and `0` if the app's HEX mode
is disabled. If the phone receives no echo and the OLED remains `BT READY`,
swap the JDY-31 TXD/RXD wiring and verify its baud rate is 9600.

## 模块化代码说明（V3）

- `main.c`：系统入口，只执行初始化和读取蓝牙数据。
- `motor.c/.h`：L298N 电机方向与 PWM 速度控制。
- `bluetooth.c/.h`：JDY-31 UART 接收、回传和命令格式兼容。
- `remote_car.c/.h`：把 00~04 命令转换为停车、前进、后退、左转、右转。
- `ssd1306.c/.h`：OLED 显示驱动。
- `empty.syscfg`：所有引脚和外设配置来源。

成功下载 V3 后，OLED 第一行必须显示 `JDY31 V3`。如果仍显示
`STATE:`，说明运行的仍是旧固件，需在 CCS 中 Clean、重新 Build 并重新
下载。第二行 `WAIT LINK` 表示等待手机连接，连接后显示 `CONNECTED`；
按键后应变为动作和命令编号。JDY-31 的 STATE 必须接到 PB4。

V6 使用非阻塞接收接口直接检查 UART 数据。按键显示分别为 `UP 01`、
`DOWN 02`、`LEFT 03`、`RIGHT 04` 和 `STOP 00`。

After importing a newer package over an existing CCS project, run **Project >
Clean**, delete the old `Debug` build configuration if the ADC panel still
reports Auto power-down, then rebuild. This project uses automatic sampling
with manual power-down. Do not change Sampling Mode to Manual: the polling
read routine starts each conversion in software and waits for the automatic
sample/conversion result.

## Line-car wiring

Keep the tested battery, power-board, motor and L298N power wiring unchanged.
All grounds must be connected together.

### Eight-channel line sensor

The sensor board is powered from 5 V. Protect the MSPM0 ADC with a divider:

| Sensor | LP-MSPM0G3507 |
| --- | --- |
| GND | GND |
| 5V | regulated 5 V from the power board |
| AD0 | PB6 (J3.13) |
| AD1 | PB7 (J3.14) |
| AD2 | PB8 (J3.15) |
| OUT | through divider to PA25 |

On the upper-right BoosterPack header, count downward from J4.20 GND:
PB8 is J3.15, PB7 is J3.14, and PB6 is J3.13.

Divider: sensor OUT -> 10 kohm -> PA25; PA25 -> 20 kohm -> GND. Do not connect
the 5 V OUT signal directly to PA25.

### L298N control

Remove the ENA and ENB jumper caps so PWM controls speed.

| L298N | LP-MSPM0G3507 |
| --- | --- |
| ENA | PA12 |
| ENB | PA13 |
| IN1 | PA8 |
| IN2 | PA9 |
| IN3 | PA16 |
| IN4 | PA17 |
| GND | GND |

Connect the two left motors in parallel to L298N output A and the two right
motors in parallel to output B. If one wheel on a side rotates backward,
reverse that motor's two wires. Based on the completed chassis test, the
program drives output A with IN2 and output B with IN3 for forward motion. The
car waits about one second at power-up to detect sensor polarity, then starts
following the line automatically.

At startup the OLED displays `TEST LEFT` and drives only ENA/PA12, then displays
`TEST RIGHT` and drives only ENB/PA13. Both sides must turn during this test.
If `TEST RIGHT` does not move the right wheels, the fault is outside the
line-following calculation: remove the ENB jumper, connect ENB to PA13, verify
IN3 to PA16 and IN4 to PA17, and swap the L298N A/B motor plugs as a quick way
to distinguish a motor/wiring fault from a damaged output channel.

The line-following code assumes black tape produces a lower ADC value and
multiplexer channel 0 is on the physical right
side of the car. If your sensor board numbers channel 0 from the left, change
`SENSOR_ORDER_REVERSED` in `line_car.c` from `1` to `0`.

If the module produces a higher voltage over black tape, change
`BLACK_IS_HIGH` from `0` to `1`. The OLED displays `LEFT`, `RIGHT`, `L90`, or
`R90` when the sensor values are being recognized; continuous `SEARCH` means
the ADC values do not have enough contrast and the OUT/divider wiring or the
sensor-board sensitivity potentiometer must be checked.

At every power-up, keep all eight sensors over the white floor while the OLED
shows `CAL WHITE`. The program records a separate white reference for every
channel, so fixed differences between sensors cannot be mistaken for a black
line. Move the middle sensors onto the black tape only after `READY` appears.
The car requires three consecutive valid line readings before starting. If no
channel differs enough from its own white reference, it stays stopped with
`NO LINE` or searches after a line has previously been detected.

The controller accepts only one to four active sensors as a valid tape line.
Five or more active sensors are treated as reflection, bad calibration, or an
invalid surface instead of a command to drive forward. A sharp turn must be
confirmed for three consecutive readings before an in-place turn begins.
When the line is lost the car now stops with `LINE LOST`; it does not spin in
the last known direction. Straight speed is limited to 48 percent and curve
speed to 42 percent.
