#include "four_line.h"

#include <stdint.h>

#include "motor.h"
#include "ssd1306.h"
#include "ti_msp_dl_config.h"

/* ===== Fast mode parameters: keep the tested second-task settings ===== */
#define STRAIGHT_SPEED 69          /* Straight: both wheels */
#define TURN_OUTER_SPEED 75        /* Normal curve: outer wheel */
#define TURN_INNER_SPEED 0         /* Normal curve: inner wheel */
#define SEARCH_SPEED 75            /* Lost line: searching wheel */

/* ===== Stable mode parameters: same logic as fast mode ===== */
#define STABLE_INITIAL_SPEED 55
#define STABLE_ACCELERATION 2
#define STABLE_STRAIGHT_SPEED 62
#define STABLE_TURN_OUTER_SPEED 75
#define STABLE_TURN_INNER_SPEED 0
#define STABLE_SEARCH_SPEED 75

#define MAX_SPEED 80
/* ================================================================= */
#define SENSOR_SETTLE_CYCLES 32000U

static uint8_t lastMask;
static uint8_t currentMask;
static uint8_t displayEnabled;
static int16_t lastError;
static int16_t stableCurrentSpeed;
static FourLineMode currentMode;

/* Motor_set channel order is opposite to the physical wheel order. */
static void setPhysicalWheels(int16_t leftSpeed, int16_t rightSpeed)
{
    Motor_set(rightSpeed, leftSpeed);
}

static int16_t clampSpeed(int16_t speed)
{
    if (speed > MAX_SPEED) return MAX_SPEED;
    if (speed < -MAX_SPEED) return -MAX_SPEED;
    return speed;
}

static void selectChannel(uint8_t channel)
{
    uint32_t allPins = SENSOR_SELECT_AD0_PIN | SENSOR_SELECT_AD1_PIN |
                       SENSOR_SELECT_AD2_PIN;
    uint32_t setPins = 0U;

    if ((channel & 1U) != 0U) setPins |= SENSOR_SELECT_AD0_PIN;
    if ((channel & 2U) != 0U) setPins |= SENSOR_SELECT_AD1_PIN;
    if ((channel & 4U) != 0U) setPins |= SENSOR_SELECT_AD2_PIN;
    DL_GPIO_clearPins(SENSOR_SELECT_PORT, allPins);
    DL_GPIO_setPins(SENSOR_SELECT_PORT, setPins);
}

static uint8_t readLineMask(void)
{
    uint8_t mask = 0U;

    for (uint8_t channel = 0U; channel < 8U; channel++) {
        selectChannel(channel);
        delay_cycles(SENSOR_SETTLE_CYCLES);
        /* Reference module logic: OUT high means this channel detects line. */
        if (DL_GPIO_readPins(SENSOR_OUT_PORT, SENSOR_OUT_OUT_PIN) != 0U) {
            mask |= (uint8_t) (0x80U >> channel);
        }
    }
    return mask;
}

static void showState(const char *state, uint8_t mask)
{
    char bits[] = "00000000";

    if (displayEnabled == 0U) return;
    if (mask == lastMask) return;
    lastMask = mask;
    for (uint8_t i = 0U; i < 8U; i++) {
        bits[i] = ((mask & (0x80U >> i)) != 0U) ? '1' : '0';
    }
    SSD1306_clear();
    SSD1306_drawString(0U, 0U, state);
    SSD1306_drawString(0U, 16U, bits);
}

void FourLine_init(void)
{
    Motor_init();
    lastMask = 0xFFU;
    currentMask = 0U;
    displayEnabled = 1U;
    lastError = 0;
    stableCurrentSpeed = STABLE_INITIAL_SPEED;
    currentMode = FOUR_LINE_MODE_FAST;
    showState("LINE MODE", readLineMask());
    delay_cycles(16000000U);
}

static void updateFast(uint8_t mask, int16_t weightedSum, uint8_t activeCount)
{
    int16_t error;
    int16_t leftSpeed;
    int16_t rightSpeed;

    if (activeCount == 0U) {
        if (lastError < 0) {
            setPhysicalWheels(0, SEARCH_SPEED);
            showState("SEARCH LEFT", mask);
        } else {
            setPhysicalWheels(SEARCH_SPEED, 0);
            showState("SEARCH RIGHT", mask);
        }
        return;
    }

    error = weightedSum / (int16_t) activeCount;

    lastError = error;

    if (error < -2) {
        leftSpeed = TURN_INNER_SPEED;
        rightSpeed = TURN_OUTER_SPEED;
    } else if (error > 2) {
        leftSpeed = TURN_OUTER_SPEED;
        rightSpeed = TURN_INNER_SPEED;
    } else {
        leftSpeed = STRAIGHT_SPEED;
        rightSpeed = STRAIGHT_SPEED;
    }

    leftSpeed = clampSpeed(leftSpeed);
    rightSpeed = clampSpeed(rightSpeed);

    setPhysicalWheels(leftSpeed, rightSpeed);
    if (error < -2) showState("CURVE LEFT", mask);
    else if (error > 2) showState("CURVE RIGHT", mask);
    else showState("STRAIGHT", mask);
}

static void updateStable(uint8_t mask, int16_t weightedSum, uint8_t activeCount)
{
    int16_t error;
    int16_t leftSpeed;
    int16_t rightSpeed;

    if (activeCount == 0U) {
        if (lastError < 0) {
            setPhysicalWheels(0, STABLE_SEARCH_SPEED);
            showState("SEARCH LEFT", mask);
        } else {
            setPhysicalWheels(STABLE_SEARCH_SPEED, 0);
            showState("SEARCH RIGHT", mask);
        }
        return;
    }

    error = weightedSum / (int16_t) activeCount;

    lastError = error;

    if (error < -2) {
        leftSpeed = STABLE_TURN_INNER_SPEED;
        rightSpeed = STABLE_TURN_OUTER_SPEED;
    } else if (error > 2) {
        leftSpeed = STABLE_TURN_OUTER_SPEED;
        rightSpeed = STABLE_TURN_INNER_SPEED;
    } else {
        leftSpeed = stableCurrentSpeed;
        rightSpeed = stableCurrentSpeed;
        stableCurrentSpeed += STABLE_ACCELERATION;
        if (stableCurrentSpeed > STABLE_STRAIGHT_SPEED) {
            stableCurrentSpeed = STABLE_STRAIGHT_SPEED;
        }
    }

    leftSpeed = clampSpeed(leftSpeed);
    rightSpeed = clampSpeed(rightSpeed);

    setPhysicalWheels(leftSpeed, rightSpeed);
    if (error < -2) showState("CURVE LEFT", mask);
    else if (error > 2) showState("CURVE RIGHT", mask);
    else showState("STRAIGHT", mask);
}

void FourLine_update(void)
{
    static const int8_t weights[8] = {-12, -8, -5, -1, 1, 5, 8, 12};
    uint8_t mask = readLineMask();
    int16_t weightedSum = 0;
    uint8_t activeCount = 0U;

    currentMask = mask;
    for (uint8_t i = 0U; i < 8U; i++) {
        if ((mask & (0x80U >> i)) != 0U) {
            weightedSum += weights[i];
            activeCount++;
        }
    }

    if (currentMode == FOUR_LINE_MODE_STABLE) {
        updateStable(mask, weightedSum, activeCount);
    } else {
        updateFast(mask, weightedSum, activeCount);
    }
}

uint8_t FourLine_getLastMask(void)
{
    return currentMask;
}

void FourLine_setDisplayEnabled(uint8_t enabled)
{
    displayEnabled = enabled;
}

void FourLine_setMode(FourLineMode mode)
{
    currentMode = mode;
    if (mode == FOUR_LINE_MODE_STABLE) {
        stableCurrentSpeed = STABLE_INITIAL_SPEED;
    }
    Motor_stop();
}

FourLineMode FourLine_getMode(void)
{
    return currentMode;
}
