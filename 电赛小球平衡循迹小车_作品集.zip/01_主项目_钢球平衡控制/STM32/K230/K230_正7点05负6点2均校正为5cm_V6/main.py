# -*- coding: utf-8 -*-
"""
?????? Lite-K230D
GC2093 CSI2 ??? -> H.264 -> Wi-Fi RTSP + YOLOv8????

???
1. YOLOv8??????????STM32????
2. ????OSD????
3. ????RTSP??????????????
4. ?????????Wi-Fi?H.264?????????

?????
   rtsp://???IP:8554/live

????
   1. ?? WIFI_PASSWORD
   2. ? model.kmodel ?? /sdcard/kmodel/ ???
   3. ??????????VLC?????????300?800 ms
"""

import os
import gc
import time
import image
import network
import uctypes
import nncase_runtime as nn
import multimedia as mm

from media.sensor import *
from media.vencoder import *
from media.media import *
from media.display import *
from libs.YOLO import YOLOv8

try:
    from machine import UART, FPIOA
except ImportError:
    UART = None
    FPIOA = None

try:
    import user_config
except ImportError:
    user_config = None

if user_config is not None:
    WIFI_SSID = getattr(user_config, "WIFI_SSID", "wyt")
    WIFI_PASSWORD = getattr(user_config, "WIFI_PASSWORD", "91306014")
    ENABLE_PHONE_LIVE_VIEW = getattr(
        user_config, "ENABLE_PHONE_LIVE_VIEW", True)
    WIFI_BOOT_DELAY_MS = getattr(user_config, "WIFI_BOOT_DELAY_MS", 5000)
    WIFI_CONNECT_TIMEOUT_S = getattr(
        user_config, "WIFI_CONNECT_TIMEOUT_S", 15)
    WIFI_CONNECT_RETRIES = getattr(user_config, "WIFI_CONNECT_RETRIES", 3)
    WIFI_RETRY_DELAY_MS = getattr(user_config, "WIFI_RETRY_DELAY_MS", 2000)
    PHONE_VIEW_FAILSAFE = getattr(user_config, "PHONE_VIEW_FAILSAFE", True)
else:
    WIFI_SSID = "wyt"
    WIFI_PASSWORD = "91306014"
    ENABLE_PHONE_LIVE_VIEW = True
    WIFI_BOOT_DELAY_MS = 5000
    WIFI_CONNECT_TIMEOUT_S = 15
    WIFI_CONNECT_RETRIES = 3
    WIFI_RETRY_DELAY_MS = 2000
    PHONE_VIEW_FAILSAFE = True


# ============================================================
# ??????
# ============================================================

# Wi-Fi and phone-view settings are in ASCII-only user_config.py.

# Coordinate link: K230 IO9 TX -> STM32 PA10 RX.
# The IO10 RX connection to STM32 PA9 TX is reserved for future feedback.
# Change the UART constants below only if the K230 wiring changes.
ENABLE_STM32_UART = True
if UART is not None:
    UART_ID = UART.UART1
else:
    UART_ID = 1
UART_BAUDRATE = 115200
UART_TX_PIN = 9             # K230 IO9 -> STM32 PA10
UART_RX_PIN = 10            # K230 IO10 <- STM32 PA9
if FPIOA is not None:
    UART_TX_FUNCTION = FPIOA.UART1_TXD
    UART_RX_FUNCTION = FPIOA.UART1_RXD
else:
    UART_TX_FUNCTION = None
    UART_RX_FUNCTION = None
UART_SEND_PERIOD_MS = 20    # 50 Hz
UART_INVALID_PERIOD_MS = 100

# ????????
RTSP_PORT = 8554
RTSP_SESSION = "live"

# YOLO????
KMODEL_PATH = "/sdcard/kmodel/model.kmodel"
LABELS = ["ball"]

# ????
DISPLAY_WIDTH = ALIGN_UP(640, 16)
DISPLAY_HEIGHT = 480
RGB888P_SIZE = [ALIGN_UP(320, 16), 240]
MODEL_INPUT = [640, 640]

# ?????
SENSOR_ID = 2
CAMERA_VFLIP = False
CAMERA_HMIRROR = False

# ???????????/??????YOLO??????
VIDEO_WIDTH = 640
VIDEO_HEIGHT = 360

# GC2093??????
SENSOR_INPUT_WIDTH = 1920
SENSOR_INPUT_HEIGHT = 1080
SENSOR_INPUT_FPS = 60

# H.264????
VIDEO_BITRATE_KBPS = 1500
VIDEO_GOP = 20
VIDEO_OUTPUT_FPS = 20

# ????????
VENC_CHANNEL = VENC_CHN_ID_0
VENC_BUFFER_NUM = 8

# RTSP???
RTSP_TIMESTAMP = 1000

# YOLO????
CONF_THRESH = 0.05
NMS_THRESH = 0.45
MAX_BOXES = 15

# ROI????????????
ROI_X1 = int(DISPLAY_WIDTH * 0.00)
ROI_Y1 = int(DISPLAY_HEIGHT * 0.35)
ROI_X2 = int(DISPLAY_WIDTH * 1.00)
ROI_Y2 = int(DISPLAY_HEIGHT * 0.65)

# ??????
MIN_BOX_PX = 8
MAX_BOX_PX = 160
MIN_ASPECT = 0.45
MAX_ASPECT = 2.20

# ????
TRACK_MAX_JUMP_PX = 180
TRACK_RESET_FRAMES = 8
FILTER_ALPHA = 0.65

# ????????
STATS_PERIOD_MS = 2000

# ==================== ???? ====================
# ????-12cm ? +12cm???0.5cm
CAL_CM = (
    -12.0, -11.5, -11.0, -10.5, -10.0, -9.5, -9.0, -8.5, -8.0,
    -7.5, -7.0, -6.5, -6.0, -5.5, -5.0, -4.5, -4.0, -3.5, -3.0,
    -2.5, -2.0, -1.5, -1.0, -0.5, 0.0,
    0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5,
    6.0, 6.5, 7.0, 7.5, 8.0, 8.5, 9.0, 9.5, 10.0, 10.5,
    11.0, 11.5, 12.0
)

CALIBRATION_WIDTH = 800
CAL_PX_ORIGINAL = (
    41, 55, 70, 85, 100, 115, 130, 145, 160,
    176, 191, 206, 222, 237, 253, 268, 283, 299, 314,
    329, 343, 358, 373, 387, 401,
    411, 422, 433, 446, 458, 472, 486, 501, 515, 531, 546,
    562, 578, 595, 611, 627, 644, 660, 676, 692, 708,
    723, 738, 753
)
CALIBRATED = True
POSITIVE_DISPLAY_OFFSET_CM = 0.5

# Independent coordinate scale calibration for the positive/negative sides.
# Positive: actual +5.00 cm, currently reported +7.05 cm.
# Negative: actual -5.00 cm, currently reported -6.20 cm.
POSITIVE_ACTUAL_CM = 5.00
POSITIVE_REPORTED_CM = 7.05
NEGATIVE_ACTUAL_CM = 5.00
NEGATIVE_REPORTED_CM = 6.20
POSITIVE_COORDINATE_SCALE = POSITIVE_ACTUAL_CM / POSITIVE_REPORTED_CM
NEGATIVE_COORDINATE_SCALE = NEGATIVE_ACTUAL_CM / NEGATIVE_REPORTED_CM


def transform_calibration_px(px):
    if CAMERA_HMIRROR:
        corrected_px = px
    else:
        corrected_px = CALIBRATION_WIDTH - 1 - px
    return corrected_px * DISPLAY_WIDTH / CALIBRATION_WIDTH


CAL_PX_BY_CM = tuple(transform_calibration_px(px) for px in CAL_PX_ORIGINAL)
CAL_PX_CM_PAIRS = sorted(zip(CAL_PX_BY_CM, CAL_CM))
CAL_PX = tuple(pair[0] for pair in CAL_PX_CM_PAIRS)
CAL_CM_BY_PX = tuple(pair[1] for pair in CAL_PX_CM_PAIRS)


def axis_map(value, src, dst):
    """??????"""
    if value <= src[0]:
        i = 0
    elif value >= src[-1]:
        i = len(src) - 2
    else:
        i = 0
        while value > src[i + 1]:
            i += 1

    span = src[i + 1] - src[i]
    if span == 0:
        return dst[i]
    return dst[i] + (value - src[i]) * (dst[i + 1] - dst[i]) / span


def pixel_to_cm(px):
    return axis_map(px, CAL_PX, CAL_CM_BY_PX)


def cm_to_pixel(cm):
    return int(axis_map(cm, CAL_CM, CAL_PX_BY_CM) + 0.5)


def calibrated_to_display_cm(cm):
    if cm > 0.0:
        cm = max(0.0, cm - POSITIVE_DISPLAY_OFFSET_CM)
        return cm * POSITIVE_COORDINATE_SCALE
    if cm < 0.0:
        return cm * NEGATIVE_COORDINATE_SCALE
    return 0.0


def display_cm_to_pixel(cm):
    if cm > 0.0:
        cm /= POSITIVE_COORDINATE_SCALE
        cm += POSITIVE_DISPLAY_OFFSET_CM
    elif cm < 0.0:
        cm /= NEGATIVE_COORDINATE_SCALE
    return cm_to_pixel(cm)


# ============================================================
# ??Wi-Fi??
# ============================================================

def connect_wifi(ssid, password, timeout_s=30):
    wlan = network.WLAN(network.STA_IF)

    if not wlan.active():
        wlan.active(True)

    print("[WiFi] ??????:", wlan.active())

    if wlan.isconnected():
        ip_info = wlan.ifconfig()
        print("[WiFi] ?????IP??:", ip_info[0])
        return wlan

    print("[WiFi] ????:", ssid)
    wlan.connect(ssid, password)

    start_ms = time.ticks_ms()
    last_print_ms = start_ms

    while not wlan.isconnected():
        os.exitpoint()

        now_ms = time.ticks_ms()
        if time.ticks_diff(now_ms, last_print_ms) >= 1000:
            waited_s = time.ticks_diff(now_ms, start_ms) // 1000
            print("[WiFi] ????????", waited_s, "?")
            last_print_ms = now_ms

        if time.ticks_diff(now_ms, start_ms) >= timeout_s * 1000:
            try:
                wlan.disconnect()
            except BaseException:
                pass
            raise OSError("Wi-Fi????")

        time.sleep_ms(100)

    # ??DHCP??IP
    dhcp_start_ms = time.ticks_ms()
    while wlan.ifconfig()[0] == "0.0.0.0":
        os.exitpoint()
        if time.ticks_diff(time.ticks_ms(), dhcp_start_ms) >= 10000:
            raise OSError("DHCP??IP????")
        time.sleep_ms(100)

    ip_info = wlan.ifconfig()
    print("[WiFi] ?????IP??:", ip_info[0])
    return wlan


def connect_wifi_with_retry(ssid, password):
    """Wait for the hotspot at boot and retry without killing main()."""
    if WIFI_BOOT_DELAY_MS > 0:
        print("[WiFi] boot delay:", WIFI_BOOT_DELAY_MS, "ms")
        time.sleep_ms(WIFI_BOOT_DELAY_MS)

    attempts = max(1, int(WIFI_CONNECT_RETRIES))
    for attempt in range(attempts):
        try:
            print("[WiFi] connect attempt %d/%d" % (attempt + 1, attempts))
            return connect_wifi(
                ssid, password, timeout_s=WIFI_CONNECT_TIMEOUT_S)
        except BaseException as exc:
            if "IDE interrupt" in repr(exc):
                raise
            print("[WiFi] attempt failed:", repr(exc))
            if attempt + 1 < attempts:
                time.sleep_ms(WIFI_RETRY_DELAY_MS)

    print("[WiFi] all attempts failed; continue without phone view")
    return None


# ============================================================
# ????????
# ============================================================

def create_h264_channel_attr(encoder, width, height):
    try:
        attr = ChnAttrStr(
            encoder.PAYLOAD_TYPE_H264,
            encoder.H264_PROFILE_MAIN,
            width,
            height,
            VIDEO_BITRATE_KBPS,
            VIDEO_GOP,
            SENSOR_INPUT_FPS,
            VIDEO_OUTPUT_FPS
        )
        print("[Video] ????:", VIDEO_BITRATE_KBPS, "kbps")
        print("[Video] GOP:", VIDEO_GOP)
        return attr
    except TypeError as exc:
        print("[Video] ??ChnAttrStr????:", repr(exc))
        print("[Video] ???????")
        return ChnAttrStr(
            encoder.PAYLOAD_TYPE_H264,
            encoder.H264_PROFILE_MAIN,
            width,
            height
        )


def create_stm32_uart():
    """??K230?STM32????????"""
    if not ENABLE_STM32_UART:
        print("[UART] STM32???????")
        return None
    if UART is None or FPIOA is None:
        print("[UART] ?????machine.UART/FPIOA????????")
        return None

    try:
        fpioa = FPIOA()
        fpioa.set_function(UART_TX_PIN, UART_TX_FUNCTION)
        fpioa.set_function(UART_RX_PIN, UART_RX_FUNCTION)
        uart = UART(UART_ID, baudrate=UART_BAUDRATE,
                    bits=UART.EIGHTBITS,
                    parity=UART.PARITY_NONE,
                    stop=UART.STOPBITS_ONE)
        print("[UART] TX pin=%d, UART%d, %d baud" %
              (UART_TX_PIN, UART_ID, UART_BAUDRATE))
        return uart
    except BaseException as exc:
        print("[UART] ???????????UART????:", repr(exc))
        return None


def send_position_frame(uart, position_cm, confidence, valid, sequence):
    """??8???: AA 55 pos_mm_L pos_mm_H conf seq flags xor?"""
    if uart is None:
        return sequence

    position_mm = int(position_cm * 10.0 +
                      (0.5 if position_cm >= 0.0 else -0.5))
    if position_mm < -32768:
        position_mm = -32768
    elif position_mm > 32767:
        position_mm = 32767

    position_u16 = position_mm & 0xFFFF
    confidence_percent = int(confidence * 100.0 + 0.5)
    confidence_percent = max(0, min(100, confidence_percent))
    flags = 0x01 if valid else 0x00

    frame = bytearray(8)
    frame[0] = 0xAA
    frame[1] = 0x55
    frame[2] = position_u16 & 0xFF
    frame[3] = (position_u16 >> 8) & 0xFF
    frame[4] = confidence_percent
    frame[5] = sequence
    frame[6] = flags
    checksum = 0
    for value in frame[:7]:
        checksum ^= value
    frame[7] = checksum
    uart.write(frame)
    return (sequence + 1) & 0xFF


# ============================================================
# ?????
# ============================================================

def main(force_disable_phone_view=False):
    wifi = None
    sensor = None
    encoder = None
    yolo = None
    media_link = None
    rtsp_server = None
    stm32_uart = None

    media_initialized = False
    encoder_created = False
    encoder_started = False
    sensor_started = False
    rtsp_initialized = False
    rtsp_started = False
    rtsp_session_created = False
    display_initialized = False
    phone_view_enabled = False
    restart_without_phone_view = False

    width = ALIGN_UP(VIDEO_WIDTH, 16)
    height = VIDEO_HEIGHT

    os.exitpoint(os.EXITPOINT_ENABLE)

    # ??????
    try:
        file_size = os.stat(KMODEL_PATH)[6]
        print("kmodel: %d bytes OK" % file_size)
    except OSError:
        print("[ERROR] ???????: " + KMODEL_PATH)
        return

    try:
        # ----------------------------------------------------
        # 1. ??Wi-Fi
        # ----------------------------------------------------
        if ENABLE_PHONE_LIVE_VIEW and not force_disable_phone_view:
            wifi = connect_wifi_with_retry(WIFI_SSID, WIFI_PASSWORD)
            phone_view_enabled = wifi is not None
            if not phone_view_enabled:
                print("[WiFi] fallback mode: YOLO + STM32 only")
        else:
            print("[WiFi] PHONE LIVE VIEW OFF - high FPS mode")

        # ----------------------------------------------------
        # 2. ??????
        # ----------------------------------------------------
        print("")
        print("========================================")
        print("[Video] ??????")
        print("========================================")

        nn.shrink_memory_pool()

        sensor = Sensor(
            id=SENSOR_ID,
            width=SENSOR_INPUT_WIDTH,
            height=SENSOR_INPUT_HEIGHT,
            fps=SENSOR_INPUT_FPS
        )

        sensor.reset()
        sensor.set_vflip(CAMERA_VFLIP)
        sensor.set_hmirror(CAMERA_HMIRROR)

        # ??0???RTSP???YUV420SP?
        sensor.set_framesize(
            width=width,
            height=height,
            chn=CAM_CHN_ID_0,
            alignment=12
        )
        sensor.set_pixformat(Sensor.YUV420SP, chn=CAM_CHN_ID_0)

        # ??2???YOLO???RGB888???
        sensor.set_framesize(
            width=RGB888P_SIZE[0],
            height=RGB888P_SIZE[1],
            chn=CAM_CHN_ID_2
        )
        sensor.set_pixformat(PIXEL_FORMAT_RGB_888_PLANAR, chn=CAM_CHN_ID_2)

        print("[Video] ????:", SENSOR_INPUT_WIDTH, "x", SENSOR_INPUT_HEIGHT, "@", SENSOR_INPUT_FPS, "fps")
        print("[Video] RTSP??:", width, "x", height)
        print("[Video] YOLO??:", RGB888P_SIZE[0], "x", RGB888P_SIZE[1])

        # RTSP?????H.264????YOLO????????????
        if phone_view_enabled:
            print("")
            print("========================================")
            print("[Video] ???H.264???")
            print("========================================")

            encoder = Encoder()
            encoder.SetOutBufs(VENC_CHANNEL, VENC_BUFFER_NUM, width, height)

            sensor_source = sensor.bind_info(chn=CAM_CHN_ID_0)["src"]
            encoder_destination = (VIDEO_ENCODE_MOD_ID, VENC_DEV_ID,
                                   VENC_CHANNEL)
            media_link = MediaManager.link(sensor_source,
                                           encoder_destination)
            print("[Video] ????VENC????")

        MediaManager.init()
        media_initialized = True
        print("[Media] MediaManager?????")

        if phone_view_enabled:
            channel_attr = create_h264_channel_attr(encoder, width, height)
            encoder.Create(VENC_CHANNEL, channel_attr)
            encoder_created = True
            print("[Video] H.264????????")

        # ----------------------------------------------------
        # 6. ???RTSP???
        # ----------------------------------------------------
        if phone_view_enabled:
            print("")
            print("========================================")
            print("[RTSP] ???RTSP???")
            print("========================================")

            rtsp_server = mm.rtsp_server()
            rtsp_server.rtspserver_init(RTSP_PORT)
            rtsp_initialized = True

            rtsp_server.rtspserver_createsession(
                RTSP_SESSION,
                mm.multi_media_type.media_h264,
                False
            )
            rtsp_session_created = True

            rtsp_server.rtspserver_start()
            rtsp_started = True
            print("[RTSP] RTSP??????????:", RTSP_PORT)

        # ----------------------------------------------------
        # 7. ???YOLO
        # ----------------------------------------------------
        print("")
        print("========================================")
        print("[YOLO] ???YOLOv8")
        print("========================================")

        yolo = YOLOv8(
            task_type="detect",
            mode="video",
            kmodel_path=KMODEL_PATH,
            labels=LABELS,
            rgb888p_size=RGB888P_SIZE,
            model_input_size=MODEL_INPUT,
            display_size=[DISPLAY_WIDTH, DISPLAY_HEIGHT],
            conf_thresh=CONF_THRESH,
            nms_thresh=NMS_THRESH,
            max_boxes_num=MAX_BOXES,
            debug_mode=0
        )
        yolo.config_preprocess()
        print("[YOLO] ?????")

        # STM32????????RTSP?????????????????
        stm32_uart = create_stm32_uart()

        # ----------------------------------------------------
        # 8. ?????????
        # ----------------------------------------------------
        if phone_view_enabled:
            encoder.Start(VENC_CHANNEL)
            encoder_started = True
            print("[Video] H.264???????")

        sensor.run()
        sensor_started = True
        print("[Video] ???????")

        # ----------------------------------------------------
        # 9. OSD?????
        # ----------------------------------------------------
        Display.init(Display.ST7701, width=DISPLAY_WIDTH,
                     height=DISPLAY_HEIGHT, osd_num=1, to_ide=False)
        display_initialized = True
        sensor_bind_info = sensor.bind_info(x=0, y=0, chn=CAM_CHN_ID_0)
        Display.bind_layer(**sensor_bind_info, layer=Display.LAYER_VIDEO1)

        osd_img = image.Image(DISPLAY_WIDTH, DISPLAY_HEIGHT, image.ARGB8888)

        print("")
        print("================================================")
        print("YOLO???? + STM32????????")
        if phone_view_enabled:
            rtsp_url = rtsp_server.rtspserver_getrtspurl(RTSP_SESSION)
            print("????:", rtsp_url)
            print("?????1280?720?30FPS?4000kbps")
        else:
            print("PHONE LIVE VIEW: OFF (HIGH FPS MODE)")
        print("================================================")
        print("")

        # ----------------------------------------------------
        # 10. ???
        # ----------------------------------------------------
        stream_data = StreamData() if phone_view_enabled else None

        total_frames = 0
        period_frames = 0
        period_bytes = 0
        stats_start_ms = time.ticks_ms()

        # YOLO????
        last_raw_x = None
        filtered_x = None
        raw_history = []
        lost_frames = TRACK_RESET_FRAMES
        roi_w = ROI_X2 - ROI_X1
        roi_h = ROI_Y2 - ROI_Y1

        fps = 0.0
        fps_frames = 0
        fps_time = time.ticks_ms()
        print_divider = 0
        uart_sequence = 0
        uart_last_send_ms = time.ticks_ms()
        uart_last_invalid_ms = uart_last_send_ms

        while True:
            os.exitpoint()

            # ---------- YOLO?? ----------
            cur_frame = sensor.snapshot(chn=CAM_CHN_ID_2)
            input_np = cur_frame.to_numpy_ref()
            result = yolo.run(input_np)

            # ??OSD
            osd_img.clear()

            # ??ROI
            osd_img.draw_rectangle(ROI_X1, ROI_Y1, roi_w, roi_h,
                                   color=(255, 255, 0), thickness=2)

            # ????
            selected = None
            valid_count = 0
            if result and len(result) > 2 and result[0] is not None:
                selected, valid_count = select_ball(
                    result[0], result[2], last_raw_x
                )

            # ??????
            if selected is not None:
                x, y, w, h, raw_cx, cy, score = selected
                lost_frames = 0

                raw_history.append(raw_cx)
                if len(raw_history) > 3:
                    raw_history.pop(0)
                median_cx = sorted(raw_history)[len(raw_history) // 2]

                if filtered_x is None:
                    filtered_x = float(median_cx)
                else:
                    filtered_x += FILTER_ALPHA * (median_cx - filtered_x)
                last_raw_x = int(filtered_x)

                calibrated_cm = pixel_to_cm(filtered_x)
                position_cm = calibrated_to_display_cm(calibrated_cm)
                position_prefix = "X:" if CALIBRATED else "X~"

                now_uart_ms = time.ticks_ms()
                if time.ticks_diff(now_uart_ms, uart_last_send_ms) >= UART_SEND_PERIOD_MS:
                    uart_sequence = send_position_frame(
                        stm32_uart, position_cm, score, True, uart_sequence)
                    uart_last_send_ms = now_uart_ms

                # ????????
                osd_img.draw_rectangle(x, y, w, h,
                                       color=(0, 255, 0), thickness=2)
                osd_img.draw_cross(int(filtered_x), cy,
                                   color=(255, 0, 0),
                                   size=12, thickness=2)
                osd_img.draw_string_advanced(
                    x, max(5, y - 22), 20,
                    "%s%+.2fcm %.2f" % (position_prefix, position_cm, score),
                    color=(0, 255, 0)
                )
                draw_scale(osd_img, filtered_x)

                print_divider += 1
                if print_divider >= 10:
                    print("RAW cx=%d | MEDIAN cx=%d | FILTER cx=%d | "
                          "X=%+.3f cm | conf=%.3f" %
                          (raw_cx, median_cx, int(filtered_x),
                           position_cm, score))
                    print_divider = 0
            else:
                lost_frames += 1
                if lost_frames >= TRACK_RESET_FRAMES:
                    last_raw_x = None
                    filtered_x = None
                    raw_history = []
                draw_scale(osd_img, None)

                now_uart_ms = time.ticks_ms()
                if time.ticks_diff(now_uart_ms, uart_last_invalid_ms) >= UART_INVALID_PERIOD_MS:
                    uart_sequence = send_position_frame(
                        stm32_uart, 0.0, 0.0, False, uart_sequence)
                    uart_last_invalid_ms = now_uart_ms

            # FPS??
            fps_frames += 1
            if fps_frames >= 10:
                now = time.ticks_ms()
                elapsed = time.ticks_diff(now, fps_time) / 1000.0
                if elapsed > 0:
                    fps = fps_frames / elapsed
                fps_time = now
                fps_frames = 0
                gc.collect()

            # OSD??
            osd_img.draw_string_advanced(
                15, 10, 22, "FPS: %.1f" % fps, color=(255, 255, 0))
            osd_img.draw_string_advanced(
                15, 36, 22, "Candidates: %d" % valid_count,
                color=(0, 255, 0) if selected is not None else (255, 0, 0))
            osd_img.draw_string_advanced(
                DISPLAY_WIDTH - 150, 10, 18,
                "CAL: OK" if CALIBRATED else "CAL: TEMP",
                color=(0, 255, 0) if CALIBRATED else (255, 128, 0))

            # ??OSD
            Display.show_image(osd_img, 0, 0, Display.LAYER_OSD3)

            # ---------- ??RTSP?? ----------
            if phone_view_enabled:
                result = encoder.GetStream(VENC_CHANNEL, stream_data)
            else:
                result = -1

            if phone_view_enabled and result in (0, None):
                try:
                    frame_bytes = 0
                    for pack_index in range(stream_data.pack_cnt):
                        packet_size = stream_data.data_size[pack_index]
                        if packet_size <= 0:
                            continue

                        packet_data = bytes(
                            uctypes.bytearray_at(
                                stream_data.data[pack_index],
                                packet_size
                            )
                        )

                        rtsp_server.rtspserver_sendvideodata(
                            RTSP_SESSION,
                            packet_data,
                            packet_size,
                            RTSP_TIMESTAMP
                        )
                        frame_bytes += packet_size

                    total_frames += 1
                    period_frames += 1
                    period_bytes += frame_bytes

                finally:
                    encoder.ReleaseStream(VENC_CHANNEL, stream_data)

            # ????
            now_ms = time.ticks_ms()
            elapsed_ms = time.ticks_diff(now_ms, stats_start_ms)

            if elapsed_ms >= STATS_PERIOD_MS:
                elapsed_s = elapsed_ms / 1000.0
                actual_fps = period_frames / elapsed_s
                bitrate_mbps = period_bytes * 8.0 / elapsed_s / 1000000.0

                if phone_view_enabled:
                    print("[Stats] RTSP FPS:", round(actual_fps, 1),
                          "??:", round(bitrate_mbps, 2), "Mbps",
                          "???:", total_frames)
                else:
                    print("[Stats] YOLO FPS:", round(fps, 1),
                          "UART: 50Hz")

                period_frames = 0
                period_bytes = 0
                stats_start_ms = now_ms

    except KeyboardInterrupt as exc:
        print("")
        print("[Main] ??????:", repr(exc))

    except BaseException as exc:
        error_text = repr(exc)
        if "IDE interrupt" in error_text:
            print("")
            print("[Main] IDE????")
        else:
            print("")
            print("========================================")
            print("[Main] ?????:", error_text)
            print("========================================")
            if phone_view_enabled and PHONE_VIEW_FAILSAFE:
                restart_without_phone_view = True
                print("[Main] phone view failed; scheduling control-only restart")

    finally:
        # ---------- ???? ----------
        print("")
        print("========================================")
        print("[Stop] ??????")
        print("========================================")

        # ?????
        if sensor_started and sensor is not None:
            try:
                sensor.stop()
                print("[Stop] ??????")
            except BaseException as exc:
                print("[Stop] sensor.stop??:", repr(exc))

        # ??????
        if media_link is not None:
            try:
                media_link.destroy()
                print("[Stop] ???????")
            except BaseException as exc:
                print("[Stop] media_link.destroy??:", repr(exc))
            media_link = None

        # ?????
        if encoder_started and encoder is not None:
            try:
                encoder.Stop(VENC_CHANNEL)
                print("[Stop] H.264??????")
            except BaseException as exc:
                print("[Stop] encoder.Stop??:", repr(exc))

        # ??????
        if encoder_created and encoder is not None:
            try:
                encoder.Destroy(VENC_CHANNEL)
                print("[Stop] H.264???????")
            except BaseException as exc:
                print("[Stop] encoder.Destroy??:", repr(exc))

        # ??YOLO
        if yolo is not None:
            try:
                yolo.deinit()
                print("[Stop] YOLO???")
            except BaseException as exc:
                print("[Stop] yolo.deinit??:", repr(exc))

        # ??RTSP
        if rtsp_started and rtsp_server is not None:
            try:
                rtsp_server.rtspserver_stop()
                print("[Stop] RTSP??????")
            except BaseException as exc:
                print("[Stop] rtspserver_stop??:", repr(exc))

        if rtsp_session_created and rtsp_server is not None:
            try:
                rtsp_server.rtspserver_destroysession(RTSP_SESSION)
                print("[Stop] RTSP?????")
            except BaseException:
                pass

        if rtsp_initialized and rtsp_server is not None:
            try:
                rtsp_server.rtspserver_deinit()
                print("[Stop] RTSP????????")
            except BaseException as exc:
                print("[Stop] rtspserver_deinit??:", repr(exc))

        if display_initialized:
            try:
                Display.deinit()
                print("[Stop] display deinitialized")
            except BaseException as exc:
                print("[Stop] Display.deinit failed:", repr(exc))

        # ??MediaManager
        if media_initialized:
            try:
                time.sleep_ms(100)
                MediaManager.deinit()
                print("[Stop] MediaManager???")
            except BaseException as exc:
                print("[Stop] MediaManager.deinit??:", repr(exc))

        # ??Wi-Fi
        if wifi is not None:
            try:
                if wifi.isconnected():
                    wifi.disconnect()
                    print("[WiFi] ???")
            except BaseException as exc:
                print("[WiFi] ????:", repr(exc))

        if stm32_uart is not None:
            try:
                stm32_uart.deinit()
                print("[UART] STM32???????")
            except BaseException:
                pass

        os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
        time.sleep_ms(100)
        gc.collect()
        print("[Main] ????")

    if restart_without_phone_view:
        time.sleep_ms(1000)
        print("[Main] restarting without Wi-Fi/H.264/RTSP")
        return main(force_disable_phone_view=True)


# ============================================================
# ??????
# ============================================================

def is_inside_roi(cx, cy):
    return ROI_X1 <= cx <= ROI_X2 and ROI_Y1 <= cy <= ROI_Y2


def select_ball(boxes, scores, previous_x):
    """??????????"""
    best = None
    best_rank = -1000000.0
    valid_count = 0

    for i in range(len(boxes)):
        x, y, w, h = map(int, boxes[i])
        score = float(scores[i])

        if w <= 0 or h <= 0:
            continue
        if w < MIN_BOX_PX or h < MIN_BOX_PX:
            continue
        if w > MAX_BOX_PX or h > MAX_BOX_PX:
            continue

        aspect = float(w) / float(h)
        if aspect < MIN_ASPECT or aspect > MAX_ASPECT:
            continue

        cx = x + (w >> 1)
        cy = y + (h >> 1)
        if not is_inside_roi(cx, cy):
            continue

        valid_count += 1
        if previous_x is None:
            rank = score * 100.0
        else:
            jump = abs(cx - previous_x)
            if jump > TRACK_MAX_JUMP_PX and score < 0.50:
                continue
            rank = score * 100.0 - jump * 0.20

        if rank > best_rank:
            best_rank = rank
            best = (x, y, w, h, cx, cy, score)

    return best, valid_count


def draw_scale(img, ball_px=None):
    """????"""
    base_y = DISPLAY_HEIGHT - 3
    left_x = display_cm_to_pixel(-5.0)
    right_x = display_cm_to_pixel(5.0)

    img.draw_line(left_x, base_y, right_x, base_y,
                  color=(255, 255, 255), thickness=2)

    for half_cm in range(-10, 11):
        cm = half_cm * 0.5
        px = display_cm_to_pixel(cm)
        is_major = (half_cm % 2 == 0)
        tick_h = 26 if half_cm == 0 else (18 if is_major else 10)
        tick_color = (0, 255, 255) if half_cm == 0 else (255, 255, 255)

        img.draw_line(px, base_y, px, base_y - tick_h,
                      color=tick_color,
                      thickness=2 if is_major else 1)

        if is_major:
            label = "O" if half_cm == 0 else ("%+d" % int(cm))
            text_x = max(0, min(DISPLAY_WIDTH - 34, px - 14))
            img.draw_string_advanced(text_x, base_y - 48, 18, label,
                                     color=tick_color)

    if ball_px is not None:
        marker_x = max(0, min(DISPLAY_WIDTH - 1, int(ball_px)))
        img.draw_circle(marker_x, base_y - 23, 5,
                        color=(255, 255, 0), thickness=3)


if __name__ == "__main__":
    main()
