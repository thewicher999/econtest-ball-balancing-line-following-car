#ifndef __BALL_CONTROL_H
#define __BALL_CONTROL_H

#include "stm32f10x.h"

typedef enum
{
    BALL_STATE_MODE1_START_DELAY = 0,
    BALL_STATE_MODE1_GO_POSITIVE,
    BALL_STATE_MODE1_GO_NEGATIVE,
    BALL_STATE_MODE1_HORIZONTAL_WAIT,
    BALL_STATE_MODE1_HOLD_NEGATIVE,
    BALL_STATE_MODE2_WAIT_VISION,
    BALL_STATE_MODE2_HOLD_ZERO,
    BALL_STATE_MODE2_BLIND_RECOVERY,
    BALL_STATE_MODE3_WAIT_VISION,
    BALL_STATE_MODE3_LEARN_TARGET,
    BALL_STATE_MODE3_HOLD_TARGET,
    BALL_STATE_MODE3_BLIND_RECOVERY
} BallControlState;

void BallControl_Init(void);
void BallControl_Tick1ms(void);
void BallControl_Process(void);
uint32_t BallControl_GetMilliseconds(void);
uint8_t BallControl_GetMode(void);
BallControlState BallControl_GetState(void);
float BallControl_GetPositionCm(void);
float BallControl_GetTargetCm(void);
uint8_t BallControl_IsTargetLearned(void);

#endif
