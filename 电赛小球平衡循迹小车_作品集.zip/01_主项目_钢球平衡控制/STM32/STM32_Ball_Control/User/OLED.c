#include "OLED.h"

#include <stdint.h>

#include "AppConfig.h"
#include "stm32f10x.h"

#define OLED_WIDTH 128U
#define OLED_PAGE_COUNT 8U

static BallControlState g_displayed_state = (BallControlState)0xFF;

static void OLED_BusDelay(void)
{
    volatile uint16_t count;

    for (count = 0U; count < 24U; ++count) {
        __NOP();
    }
}

static void OLED_SclHigh(void)
{
    GPIO_SetBits(OLED_GPIO, OLED_SCL_PIN);
}

static void OLED_SclLow(void)
{
    GPIO_ResetBits(OLED_GPIO, OLED_SCL_PIN);
}

static void OLED_SdaHigh(void)
{
    GPIO_SetBits(OLED_GPIO, OLED_SDA_PIN);
}

static void OLED_SdaLow(void)
{
    GPIO_ResetBits(OLED_GPIO, OLED_SDA_PIN);
}

static void OLED_I2cStart(void)
{
    OLED_SdaHigh();
    OLED_SclHigh();
    OLED_BusDelay();
    OLED_SdaLow();
    OLED_BusDelay();
    OLED_SclLow();
}

static void OLED_I2cStop(void)
{
    OLED_SdaLow();
    OLED_SclHigh();
    OLED_BusDelay();
    OLED_SdaHigh();
    OLED_BusDelay();
}

static void OLED_I2cWriteByte(uint8_t value)
{
    uint8_t mask;

    for (mask = 0x80U; mask != 0U; mask >>= 1U) {
        if ((value & mask) != 0U) {
            OLED_SdaHigh();
        } else {
            OLED_SdaLow();
        }
        OLED_BusDelay();
        OLED_SclHigh();
        OLED_BusDelay();
        OLED_SclLow();
    }

    /* Release SDA for the OLED ACK bit. */
    OLED_SdaHigh();
    OLED_BusDelay();
    OLED_SclHigh();
    OLED_BusDelay();
    OLED_SclLow();
}

static void OLED_WriteCommand(uint8_t command)
{
    OLED_I2cStart();
    OLED_I2cWriteByte((uint8_t)(OLED_I2C_ADDRESS << 1U));
    OLED_I2cWriteByte(0x00U);
    OLED_I2cWriteByte(command);
    OLED_I2cStop();
}

static void OLED_WriteData(const uint8_t *data, uint16_t length)
{
    uint16_t index;

    OLED_I2cStart();
    OLED_I2cWriteByte((uint8_t)(OLED_I2C_ADDRESS << 1U));
    OLED_I2cWriteByte(0x40U);
    for (index = 0U; index < length; ++index) {
        OLED_I2cWriteByte(data[index]);
    }
    OLED_I2cStop();
}

static void OLED_SetCursor(uint8_t x, uint8_t page)
{
    OLED_WriteCommand((uint8_t)(0xB0U | page));
    OLED_WriteCommand((uint8_t)(x & 0x0FU));
    OLED_WriteCommand((uint8_t)(0x10U | (x >> 4U)));
}

static const uint8_t *OLED_GetGlyph(char character)
{
    static const uint8_t blank[5] = {0U, 0U, 0U, 0U, 0U};
    static const uint8_t font[][5] = {
        {0x3E,0x51,0x49,0x45,0x3E}, {0x00,0x42,0x7F,0x40,0x00},
        {0x42,0x61,0x51,0x49,0x46}, {0x21,0x41,0x45,0x4B,0x31},
        {0x18,0x14,0x12,0x7F,0x10}, {0x27,0x45,0x45,0x45,0x39},
        {0x3C,0x4A,0x49,0x49,0x30}, {0x01,0x71,0x09,0x05,0x03},
        {0x36,0x49,0x49,0x49,0x36}, {0x06,0x49,0x49,0x29,0x1E},
        {0x7E,0x11,0x11,0x11,0x7E}, {0x7F,0x49,0x49,0x49,0x36},
        {0x3E,0x41,0x41,0x41,0x22}, {0x7F,0x41,0x41,0x22,0x1C},
        {0x7F,0x49,0x49,0x49,0x41}, {0x7F,0x09,0x09,0x09,0x01},
        {0x3E,0x41,0x49,0x49,0x7A}, {0x7F,0x08,0x08,0x08,0x7F},
        {0x00,0x41,0x7F,0x41,0x00}, {0x20,0x40,0x41,0x3F,0x01},
        {0x7F,0x08,0x14,0x22,0x41}, {0x7F,0x40,0x40,0x40,0x40},
        {0x7F,0x02,0x0C,0x02,0x7F}, {0x7F,0x04,0x08,0x10,0x7F},
        {0x3E,0x41,0x41,0x41,0x3E}, {0x7F,0x09,0x09,0x09,0x06},
        {0x3E,0x41,0x51,0x21,0x5E}, {0x7F,0x09,0x19,0x29,0x46},
        {0x46,0x49,0x49,0x49,0x31}, {0x01,0x01,0x7F,0x01,0x01},
        {0x3F,0x40,0x40,0x40,0x3F}, {0x1F,0x20,0x40,0x20,0x1F},
        {0x7F,0x20,0x18,0x20,0x7F}, {0x63,0x14,0x08,0x14,0x63},
        {0x03,0x04,0x78,0x04,0x03}, {0x61,0x51,0x49,0x45,0x43}
    };
    static const uint8_t plus[5] = {0x08,0x08,0x3E,0x08,0x08};
    static const uint8_t minus[5] = {0x08,0x08,0x08,0x08,0x08};
    static const uint8_t greater[5] = {0x00,0x41,0x22,0x14,0x08};

    if (character >= 'a' && character <= 'z') {
        character = (char)(character - 'a' + 'A');
    }
    if (character >= '0' && character <= '9') {
        return font[character - '0'];
    }
    if (character >= 'A' && character <= 'Z') {
        return font[10 + character - 'A'];
    }
    if (character == '+') return plus;
    if (character == '-') return minus;
    if (character == '>') return greater;
    return blank;
}

static void OLED_Clear(void)
{
    uint8_t page;
    uint8_t zeros[OLED_WIDTH];
    uint16_t index;

    for (index = 0U; index < OLED_WIDTH; ++index) {
        zeros[index] = 0U;
    }
    for (page = 0U; page < OLED_PAGE_COUNT; ++page) {
        OLED_SetCursor(0U, page);
        OLED_WriteData(zeros, OLED_WIDTH);
    }
}

static void OLED_DrawString(uint8_t x, uint8_t page, const char *text)
{
    uint8_t character[6];
    uint8_t column = x;
    uint8_t index;
    const uint8_t *glyph;

    while (*text != '\0' && (uint16_t)column + 6U <= OLED_WIDTH) {
        glyph = OLED_GetGlyph(*text++);
        for (index = 0U; index < 5U; ++index) {
            character[index] = glyph[index];
        }
        character[5] = 0U;
        OLED_SetCursor(column, page);
        OLED_WriteData(character, sizeof(character));
        column = (uint8_t)(column + sizeof(character));
    }
}

void OLED_Init(void)
{
    GPIO_InitTypeDef gpio;
    static const uint8_t commands[] = {
        0xAE,0xD5,0x80,0xA8,0x3F,0xD3,0x00,0x40,
        0x8D,0x14,0x20,0x02,0xA1,0xC8,0xDA,0x12,
        0x81,0xCF,0xD9,0xF1,0xDB,0x40,0xA4,0xA6,0xAF
    };
    uint8_t index;
    volatile uint32_t startup_delay;

    RCC_APB2PeriphClockCmd(OLED_GPIO_CLOCK, ENABLE);
    gpio.GPIO_Pin = OLED_SCL_PIN | OLED_SDA_PIN;
    gpio.GPIO_Mode = GPIO_Mode_Out_OD;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(OLED_GPIO, &gpio);
    OLED_SclHigh();
    OLED_SdaHigh();

    for (startup_delay = 0U; startup_delay < 720000U; ++startup_delay) {
        __NOP();
    }
    for (index = 0U; index < sizeof(commands); ++index) {
        OLED_WriteCommand(commands[index]);
    }
    OLED_Clear();
    g_displayed_state = (BallControlState)0xFF;
}

void OLED_ShowControlState(BallControlState state)
{
    const char *state_text;
    const char *mode_text;

    if (state == g_displayed_state) {
        return;
    }
    g_displayed_state = state;

    if (state == BALL_STATE_MODE1_GO_POSITIVE) {
        state_text = "TO POSITIVE 5CM";
        mode_text = "MODE1 OPEN/CLOSE";
    } else if (state == BALL_STATE_MODE1_GO_NEGATIVE) {
        state_text = "TO NEGATIVE 5CM";
        mode_text = "MODE1 OPEN/CLOSE";
    } else if (state == BALL_STATE_MODE1_HORIZONTAL_WAIT) {
        state_text = "HORIZONTAL WAIT";
        mode_text = "MODE1 WAIT PID";
    } else if (state == BALL_STATE_MODE1_HOLD_NEGATIVE) {
        state_text = "HOLD NEGATIVE 5";
        mode_text = "MODE1 K230 PID";
    } else if (state == BALL_STATE_MODE2_WAIT_VISION) {
        state_text = "WAIT K230 BALL";
        mode_text = "MODE2 HOLD 0CM";
    } else if (state == BALL_STATE_MODE2_HOLD_ZERO) {
        state_text = "HOLD ZERO CM";
        mode_text = "MODE2 PID ACTIVE";
    } else if (state == BALL_STATE_MODE2_BLIND_RECOVERY) {
        state_text = "BLIND RECOVERY";
        mode_text = "MODE2 RESCUE";
    } else if (state == BALL_STATE_MODE3_WAIT_VISION) {
        state_text = "WAIT K230 BALL";
        mode_text = "MODE3 HOLD ANY";
    } else if (state == BALL_STATE_MODE3_LEARN_TARGET) {
        state_text = "LEARN TARGET";
        mode_text = "MODE3 LEARNING";
    } else if (state == BALL_STATE_MODE3_HOLD_TARGET) {
        state_text = "HOLD TARGET";
        mode_text = "MODE3 PID ACTIVE";
    } else if (state == BALL_STATE_MODE3_BLIND_RECOVERY) {
        state_text = "BLIND RECOVERY";
        mode_text = "MODE3 RESCUE";
    } else {
        state_text = "START DELAY 2 SEC";
        mode_text = "MODE1 OPEN/CLOSE";
    }

    OLED_Clear();
    OLED_DrawString(0U, 0U, "STM32 BALL CTRL");
    OLED_DrawString(0U, 2U, "CURRENT PROCESS");
    OLED_DrawString(0U, 4U, state_text);
    OLED_DrawString(0U, 7U, mode_text);
}
