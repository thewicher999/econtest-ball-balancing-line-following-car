#ifndef __OLED_H
#define __OLED_H

#include "BallControl.h"

void OLED_Init(void);
void OLED_ShowControlState(BallControlState state);

#endif
