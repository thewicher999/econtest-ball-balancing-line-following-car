#ifndef __K230_PROTOCOL_H
#define __K230_PROTOCOL_H

#include "stm32f10x.h"

#define K230_CONTROL_MODE_POS_NEG     1U
#define K230_CONTROL_MODE_HOLD_ZERO   2U
#define K230_CONTROL_MODE_HOLD_ANY    3U

typedef struct
{
    int16_t position_mm;
    uint8_t confidence_percent;
    uint8_t sequence;
    uint8_t valid;
    uint8_t control_mode;
    uint32_t received_ms;
} K230PositionFrame;

void K230Protocol_Init(void);
void K230Protocol_OnRxByte(uint8_t byte, uint32_t now_ms);
uint8_t K230Protocol_GetLatest(K230PositionFrame *frame);

#endif
