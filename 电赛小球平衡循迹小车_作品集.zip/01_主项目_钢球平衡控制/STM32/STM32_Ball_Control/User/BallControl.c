#include "BallControl.h"
#include "AppConfig.h"
#include "K230Protocol.h"
#include "Servo.h"

/* ================= Mode 2: hold 0 cm ================= */
#define MODE2_TARGET_CM                 (0.0f)
#define MODE2_POSITION_KP               30.0f
#define MODE2_POSITION_KI               1.0f
#define MODE2_POSITION_KD               16.0f
#define MODE2_INTEGRAL_LIMIT            35.0f
#define MODE2_BLIND_STRONG_US           60.0f
#define MODE2_BLIND_GENTLE_US           40.0f

/* ============= Mode 3: learn and hold any point ============= */
#define MODE3_LEARN_DURATION_MS         2000U
#define MODE3_LEARN_MIN_SAMPLES         50U
#define MODE3_LEARN_STABILITY_TOL_CM    0.80f
#define MODE3_POSITION_KP               30.0f
#define MODE3_POSITION_KI               2.0f
#define MODE3_POSITION_KD               16.0f
#define MODE3_INTEGRAL_LIMIT            50.0f
#define MODE3_BLIND_STRONG_US           75.0f
#define MODE3_BLIND_GENTLE_US           50.0f

/* Shared blind-zone recovery thresholds and timing. */
#define BLIND_POSITIVE_TRIGGER_CM       (+9.0f)
#define BLIND_NEGATIVE_TRIGGER_CM       (-10.0f)
#define BLIND_RECOVERY_DELAY_MS         150U
#define BLIND_RECOVERY_STRONG_MS        400U
#define BLIND_RECOVERY_TIMEOUT_MS       2000U

static volatile uint32_t g_milliseconds = 0U;
static volatile uint8_t g_control_due = 0U;

static uint8_t g_control_mode = K230_CONTROL_MODE_POS_NEG;
static uint8_t g_mode_received = 0U;
static BallControlState g_state = BALL_STATE_MODE1_START_DELAY;
static uint32_t g_state_start_ms = 0U;

static float g_position_cm = 0.0f;
static float g_velocity_cm_s = 0.0f;
static float g_integral = 0.0f;
static float g_control_output_us = 0.0f;
static uint32_t g_last_measurement_ms = 0U;
static uint8_t g_last_sequence = 0U;
static uint8_t g_have_measurement = 0U;

static float g_target_cm = 0.0f;
static float g_learning_sum_cm = 0.0f;
static uint32_t g_learning_start_ms = 0U;
static uint16_t g_learning_samples = 0U;
static uint8_t g_target_learned = 0U;

static float g_last_valid_position_cm = 0.0f;
static uint32_t g_last_valid_received_ms = 0U;
static uint32_t g_blind_recovery_start_ms = 0U;
static uint8_t g_have_last_valid_position = 0U;
static uint8_t g_blind_recovery_active = 0U;
static uint8_t g_blind_recovery_attempted = 0U;
static int8_t g_blind_recovery_direction = 0;

static float AbsFloat(float value)
{
    return (value < 0.0f) ? -value : value;
}

static float ClampFloat(float value, float minimum, float maximum)
{
    if (value < minimum) {
        return minimum;
    }
    if (value > maximum) {
        return maximum;
    }
    return value;
}

static void StatusLedInit(void)
{
    GPIO_InitTypeDef gpio;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    gpio.GPIO_Pin = STATUS_LED_PIN;
    gpio.GPIO_Mode = GPIO_Mode_Out_PP;
    gpio.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_Init(STATUS_LED_GPIO, &gpio);
    GPIO_SetBits(STATUS_LED_GPIO, STATUS_LED_PIN);
}

static void UpdateStatusLed(uint8_t link_ok)
{
    uint32_t phase;

    if (g_state == BALL_STATE_MODE2_BLIND_RECOVERY ||
        g_state == BALL_STATE_MODE3_BLIND_RECOVERY) {
        phase = g_milliseconds % 200U;
        GPIO_WriteBit(STATUS_LED_GPIO, STATUS_LED_PIN,
                      (phase < 100U) ? Bit_RESET : Bit_SET);
        return;
    }

    if (g_control_mode == K230_CONTROL_MODE_POS_NEG) {
        if (g_state == BALL_STATE_MODE1_HOLD_NEGATIVE && link_ok) {
            GPIO_ResetBits(STATUS_LED_GPIO, STATUS_LED_PIN);
        } else {
            phase = g_milliseconds % 1000U;
            GPIO_WriteBit(STATUS_LED_GPIO, STATUS_LED_PIN,
                          (phase < 100U) ? Bit_RESET : Bit_SET);
        }
    } else if (link_ok &&
               (g_state == BALL_STATE_MODE2_HOLD_ZERO ||
                g_state == BALL_STATE_MODE3_HOLD_TARGET)) {
        GPIO_ResetBits(STATUS_LED_GPIO, STATUS_LED_PIN);
    } else {
        phase = g_milliseconds % 400U;
        GPIO_WriteBit(STATUS_LED_GPIO, STATUS_LED_PIN,
                      (phase < 200U) ? Bit_RESET : Bit_SET);
    }
}

static void ResetMeasurement(void)
{
    g_velocity_cm_s = 0.0f;
    g_integral = 0.0f;
    g_control_output_us = 0.0f;
    g_last_measurement_ms = 0U;
    g_last_sequence = 0U;
    g_have_measurement = 0U;
}

static void ResetLearning(void)
{
    g_target_cm = 0.0f;
    g_learning_sum_cm = 0.0f;
    g_learning_start_ms = 0U;
    g_learning_samples = 0U;
    g_target_learned = 0U;
}

static void ResetBlindRecovery(void)
{
    g_last_valid_position_cm = 0.0f;
    g_last_valid_received_ms = 0U;
    g_blind_recovery_start_ms = 0U;
    g_have_last_valid_position = 0U;
    g_blind_recovery_active = 0U;
    g_blind_recovery_attempted = 0U;
    g_blind_recovery_direction = 0;
}

static void EnterMode1State(BallControlState state, uint32_t now_ms)
{
    g_state = state;
    g_state_start_ms = now_ms;

    if (state == BALL_STATE_MODE1_GO_POSITIVE) {
        Servo_SetAngle(OPEN_LOOP_POSITIVE_ANGLE_DEG);
    } else if (state == BALL_STATE_MODE1_GO_NEGATIVE) {
        Servo_SetAngle(OPEN_LOOP_NEGATIVE_ANGLE_DEG);
    } else {
        Servo_Center();
    }

    if (state == BALL_STATE_MODE1_HOLD_NEGATIVE) {
        ResetMeasurement();
        g_control_due = 1U;
    }
}

static void SelectControlMode(uint8_t control_mode, uint32_t now_ms)
{
    if (control_mode < K230_CONTROL_MODE_POS_NEG ||
        control_mode > K230_CONTROL_MODE_HOLD_ANY) {
        control_mode = K230_CONTROL_MODE_POS_NEG;
    }

    g_control_mode = control_mode;
    g_position_cm = 0.0f;
    ResetMeasurement();
    ResetLearning();
    ResetBlindRecovery();
    Servo_SelectControlMode(control_mode);

    if (control_mode == K230_CONTROL_MODE_POS_NEG) {
        EnterMode1State(BALL_STATE_MODE1_START_DELAY, now_ms);
    } else if (control_mode == K230_CONTROL_MODE_HOLD_ZERO) {
        g_target_cm = MODE2_TARGET_CM;
        g_state = BALL_STATE_MODE2_WAIT_VISION;
        g_state_start_ms = now_ms;
    } else {
        g_state = BALL_STATE_MODE3_WAIT_VISION;
        g_state_start_ms = now_ms;
    }
    g_control_due = 1U;
}

static uint8_t FrameHasValidPosition(const K230PositionFrame *frame,
                                     uint8_t has_frame,
                                     uint32_t now_ms,
                                     float *measured_cm)
{
    if (!has_frame || !frame->valid ||
        (now_ms - frame->received_ms) > K230_LINK_TIMEOUT_MS) {
        return 0U;
    }

    *measured_cm = (float)frame->position_mm * 0.1f;
    if (*measured_cm < POSITION_VALID_MIN_CM ||
        *measured_cm > POSITION_VALID_MAX_CM) {
        return 0U;
    }
    return 1U;
}

static uint8_t UpdateMeasurement(const K230PositionFrame *frame,
                                 float measured_cm)
{
    float dt;
    float raw_velocity;

    if (!g_have_measurement) {
        g_position_cm = measured_cm;
        g_last_measurement_ms = frame->received_ms;
        g_last_sequence = frame->sequence;
        g_have_measurement = 1U;
        return 1U;
    }

    if (frame->sequence == g_last_sequence) {
        return 0U;
    }

    dt = (float)(frame->received_ms - g_last_measurement_ms) * 0.001f;
    if (dt >= 0.005f && dt <= 0.5f) {
        raw_velocity = (measured_cm - g_position_cm) / dt;
        raw_velocity = ClampFloat(raw_velocity,
                                  -MAX_MEASURED_SPEED_CM_S,
                                  MAX_MEASURED_SPEED_CM_S);
        g_velocity_cm_s += VELOCITY_FILTER_ALPHA *
                           (raw_velocity - g_velocity_cm_s);
    }
    g_position_cm = measured_cm;
    g_last_measurement_ms = frame->received_ms;
    g_last_sequence = frame->sequence;
    return 1U;
}

static void AcceptValidPosition(const K230PositionFrame *frame,
                                float measured_cm)
{
    g_last_valid_position_cm = measured_cm;
    g_last_valid_received_ms = frame->received_ms;
    g_have_last_valid_position = 1U;
    g_blind_recovery_active = 0U;
    g_blind_recovery_attempted = 0U;
    g_blind_recovery_direction = 0;
}

static uint8_t StartBlindRecovery(uint32_t now_ms)
{
    if (!g_have_last_valid_position || g_blind_recovery_attempted) {
        return 0U;
    }
    if ((now_ms - g_last_valid_received_ms) < BLIND_RECOVERY_DELAY_MS) {
        return 0U;
    }

    if (g_last_valid_position_cm >= BLIND_POSITIVE_TRIGGER_CM) {
        g_blind_recovery_direction = -1;
    } else if (g_last_valid_position_cm <= BLIND_NEGATIVE_TRIGGER_CM) {
        g_blind_recovery_direction = +1;
    } else {
        return 0U;
    }

    if (g_control_mode == K230_CONTROL_MODE_HOLD_ZERO) {
        g_state = BALL_STATE_MODE2_BLIND_RECOVERY;
    } else {
        g_state = BALL_STATE_MODE3_BLIND_RECOVERY;
    }
    g_blind_recovery_start_ms = now_ms;
    g_blind_recovery_active = 1U;
    g_blind_recovery_attempted = 1U;
    ResetMeasurement();
    return 1U;
}

static void RunBlindRecovery(uint32_t now_ms)
{
    uint32_t elapsed_ms = now_ms - g_blind_recovery_start_ms;
    float strong_us;
    float gentle_us;
    float recovery_control_us;

    if (elapsed_ms >= BLIND_RECOVERY_TIMEOUT_MS) {
        g_blind_recovery_active = 0U;
        g_blind_recovery_direction = 0;
        Servo_Center();
        if (g_control_mode == K230_CONTROL_MODE_HOLD_ZERO) {
            g_state = BALL_STATE_MODE2_WAIT_VISION;
        } else {
            g_state = g_target_learned ? BALL_STATE_MODE3_HOLD_TARGET :
                                         BALL_STATE_MODE3_WAIT_VISION;
        }
        return;
    }

    if (g_control_mode == K230_CONTROL_MODE_HOLD_ZERO) {
        strong_us = MODE2_BLIND_STRONG_US;
        gentle_us = MODE2_BLIND_GENTLE_US;
    } else {
        strong_us = MODE3_BLIND_STRONG_US;
        gentle_us = MODE3_BLIND_GENTLE_US;
    }
    recovery_control_us = (elapsed_ms < BLIND_RECOVERY_STRONG_MS) ?
                          strong_us : gentle_us;
    Servo_SetControl((float)g_blind_recovery_direction *
                     recovery_control_us);
}

static void HandleInvalidLink(uint32_t now_ms)
{
    if (g_blind_recovery_active) {
        RunBlindRecovery(now_ms);
        return;
    }
    if (StartBlindRecovery(now_ms)) {
        RunBlindRecovery(now_ms);
        return;
    }

    Servo_Center();
    ResetMeasurement();
    if (g_control_mode == K230_CONTROL_MODE_HOLD_ZERO) {
        g_state = BALL_STATE_MODE2_WAIT_VISION;
    } else if (g_target_learned) {
        g_state = BALL_STATE_MODE3_HOLD_TARGET;
    } else {
        ResetLearning();
        g_state = BALL_STATE_MODE3_WAIT_VISION;
    }
}

static void ProcessMode1ClosedLoop(const K230PositionFrame *frame,
                                   uint8_t has_frame,
                                   uint32_t now_ms)
{
    float measured_cm;
    float error;
    float output;
    float output_change;

    if (!g_control_due) {
        return;
    }
    g_control_due = 0U;

    if (!FrameHasValidPosition(frame, has_frame, now_ms, &measured_cm)) {
        Servo_Center();
        ResetMeasurement();
        UpdateStatusLed(0U);
        return;
    }

    UpdateMeasurement(frame, measured_cm);
    error = CLOSED_LOOP_TARGET_CM - g_position_cm;
    g_integral += error * ((float)CLOSED_LOOP_PERIOD_MS * 0.001f);
    g_integral = ClampFloat(g_integral,
                            -CLOSED_LOOP_INTEGRAL_LIMIT,
                            CLOSED_LOOP_INTEGRAL_LIMIT);

    output = CLOSED_LOOP_KP * error + CLOSED_LOOP_KI * g_integral -
             CLOSED_LOOP_KD * g_velocity_cm_s;
    output = ClampFloat(output,
                        -CLOSED_LOOP_MAX_CONTROL_US,
                        CLOSED_LOOP_MAX_CONTROL_US);
    output_change = output - g_control_output_us;
    output_change = ClampFloat(output_change,
                               -CLOSED_LOOP_SLEW_US_PER_CYCLE,
                               CLOSED_LOOP_SLEW_US_PER_CYCLE);
    g_control_output_us += output_change;
    Servo_SetControl(g_control_output_us);
    UpdateStatusLed(1U);
}

static void ProcessMode1(const K230PositionFrame *frame,
                         uint8_t has_frame,
                         uint32_t now_ms)
{
    uint32_t elapsed_ms = now_ms - g_state_start_ms;

    if (g_state == BALL_STATE_MODE1_START_DELAY) {
        UpdateStatusLed(0U);
        if (elapsed_ms >= OPEN_LOOP_START_DELAY_MS) {
            EnterMode1State(BALL_STATE_MODE1_GO_POSITIVE, now_ms);
        }
    } else if (g_state == BALL_STATE_MODE1_GO_POSITIVE) {
        UpdateStatusLed(0U);
        if (elapsed_ms >= OPEN_LOOP_POSITIVE_TIME_MS) {
            EnterMode1State(BALL_STATE_MODE1_GO_NEGATIVE, now_ms);
        }
    } else if (g_state == BALL_STATE_MODE1_GO_NEGATIVE) {
        UpdateStatusLed(0U);
        if (elapsed_ms >= OPEN_LOOP_NEGATIVE_TIME_MS) {
            EnterMode1State(BALL_STATE_MODE1_HORIZONTAL_WAIT, now_ms);
        }
    } else if (g_state == BALL_STATE_MODE1_HORIZONTAL_WAIT) {
        UpdateStatusLed(0U);
        if (elapsed_ms >= HORIZONTAL_WAIT_BEFORE_CLOSED_LOOP_MS) {
            EnterMode1State(BALL_STATE_MODE1_HOLD_NEGATIVE, now_ms);
        }
    } else {
        ProcessMode1ClosedLoop(frame, has_frame, now_ms);
    }
}

static void ProcessMode2(const K230PositionFrame *frame,
                         uint8_t has_frame,
                         uint32_t now_ms)
{
    float measured_cm;
    float error;
    float output;

    if (!g_control_due) {
        return;
    }
    g_control_due = 0U;

    if (!FrameHasValidPosition(frame, has_frame, now_ms, &measured_cm)) {
        HandleInvalidLink(now_ms);
        UpdateStatusLed(0U);
        return;
    }

    AcceptValidPosition(frame, measured_cm);
    UpdateMeasurement(frame, measured_cm);
    g_state = BALL_STATE_MODE2_HOLD_ZERO;
    g_target_cm = MODE2_TARGET_CM;

    error = MODE2_TARGET_CM - g_position_cm;
    g_integral += error * ((float)CLOSED_LOOP_PERIOD_MS * 0.001f);
    g_integral = ClampFloat(g_integral,
                            -MODE2_INTEGRAL_LIMIT,
                            MODE2_INTEGRAL_LIMIT);
    output = MODE2_POSITION_KP * error + MODE2_POSITION_KI * g_integral -
             MODE2_POSITION_KD * g_velocity_cm_s;
    Servo_SetControl(output);
    UpdateStatusLed(1U);
}

static void RestartMode3Learning(float sample_cm, uint32_t sample_ms)
{
    g_state = BALL_STATE_MODE3_LEARN_TARGET;
    g_target_cm = sample_cm;
    g_learning_sum_cm = sample_cm;
    g_learning_start_ms = sample_ms;
    g_learning_samples = 1U;
}

static void UpdateMode3Learning(float sample_cm, uint32_t sample_ms)
{
    float current_average;

    if (g_learning_samples == 0U) {
        RestartMode3Learning(sample_cm, sample_ms);
        return;
    }

    current_average = g_learning_sum_cm / (float)g_learning_samples;
    if (AbsFloat(sample_cm - current_average) >
        MODE3_LEARN_STABILITY_TOL_CM) {
        RestartMode3Learning(sample_cm, sample_ms);
        return;
    }

    g_learning_sum_cm += sample_cm;
    ++g_learning_samples;
    g_target_cm = g_learning_sum_cm / (float)g_learning_samples;

    if ((sample_ms - g_learning_start_ms) >= MODE3_LEARN_DURATION_MS &&
        g_learning_samples >= MODE3_LEARN_MIN_SAMPLES) {
        g_target_learned = 1U;
        g_state = BALL_STATE_MODE3_HOLD_TARGET;
        g_integral = 0.0f;
        g_velocity_cm_s = 0.0f;
    }
}

static void ProcessMode3(const K230PositionFrame *frame,
                         uint8_t has_frame,
                         uint32_t now_ms)
{
    uint8_t new_measurement;
    float measured_cm;
    float error;
    float output;

    if (!g_control_due) {
        return;
    }
    g_control_due = 0U;

    if (!FrameHasValidPosition(frame, has_frame, now_ms, &measured_cm)) {
        HandleInvalidLink(now_ms);
        UpdateStatusLed(0U);
        return;
    }

    AcceptValidPosition(frame, measured_cm);
    new_measurement = UpdateMeasurement(frame, measured_cm);

    if (!g_target_learned) {
        if (new_measurement) {
            UpdateMode3Learning(g_position_cm, frame->received_ms);
        }
        Servo_Center();
        UpdateStatusLed(1U);
        return;
    }

    g_state = BALL_STATE_MODE3_HOLD_TARGET;
    error = g_target_cm - g_position_cm;
    g_integral += error * ((float)CLOSED_LOOP_PERIOD_MS * 0.001f);
    g_integral = ClampFloat(g_integral,
                            -MODE3_INTEGRAL_LIMIT,
                            MODE3_INTEGRAL_LIMIT);
    output = MODE3_POSITION_KP * error + MODE3_POSITION_KI * g_integral -
             MODE3_POSITION_KD * g_velocity_cm_s;
    Servo_SetControl(output);
    UpdateStatusLed(1U);
}

void BallControl_Init(void)
{
    g_milliseconds = 0U;
    g_mode_received = 0U;
    StatusLedInit();
    SelectControlMode(K230_CONTROL_MODE_POS_NEG, 0U);
}

void BallControl_Tick1ms(void)
{
    ++g_milliseconds;
    if ((g_milliseconds % CLOSED_LOOP_PERIOD_MS) == 0U) {
        g_control_due = 1U;
    }
}

void BallControl_Process(void)
{
    K230PositionFrame frame;
    uint8_t has_frame;
    uint32_t now_ms = g_milliseconds;

    has_frame = K230Protocol_GetLatest(&frame);
    if (has_frame &&
        frame.control_mode >= K230_CONTROL_MODE_POS_NEG &&
        frame.control_mode <= K230_CONTROL_MODE_HOLD_ANY) {
        if (!g_mode_received || frame.control_mode != g_control_mode) {
            SelectControlMode(frame.control_mode, now_ms);
        }
        g_mode_received = 1U;
    }

    /* Stay level until the paired K230 script has sent a mode field. */
    if (!g_mode_received) {
        Servo_Center();
        UpdateStatusLed(0U);
        return;
    }

    if (g_control_mode == K230_CONTROL_MODE_HOLD_ZERO) {
        ProcessMode2(&frame, has_frame, now_ms);
    } else if (g_control_mode == K230_CONTROL_MODE_HOLD_ANY) {
        ProcessMode3(&frame, has_frame, now_ms);
    } else {
        ProcessMode1(&frame, has_frame, now_ms);
    }
}

uint32_t BallControl_GetMilliseconds(void)
{
    return g_milliseconds;
}

uint8_t BallControl_GetMode(void)
{
    return g_control_mode;
}

BallControlState BallControl_GetState(void)
{
    return g_state;
}

float BallControl_GetPositionCm(void)
{
    return g_position_cm;
}

float BallControl_GetTargetCm(void)
{
    if (g_control_mode == K230_CONTROL_MODE_POS_NEG) {
        return CLOSED_LOOP_TARGET_CM;
    }
    if (g_control_mode == K230_CONTROL_MODE_HOLD_ZERO) {
        return MODE2_TARGET_CM;
    }
    return g_target_cm;
}

uint8_t BallControl_IsTargetLearned(void)
{
    return g_target_learned;
}
