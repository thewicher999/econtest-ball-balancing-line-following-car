#include "Servo.h"
#include "AppConfig.h"

static int16_t g_servo_center_us = SERVO_CENTER_US;
static int16_t g_servo_min_us = SERVO_MIN_US;
static int16_t g_servo_max_us = SERVO_MAX_US;
static float g_servo_direction = SERVO_CONTROL_DIRECTION;
static float g_servo_us_per_deg = SERVO_US_PER_DEG;
static int16_t g_servo_pulse_us = SERVO_CENTER_US;

void Servo_Init(void)
{
    GPIO_InitTypeDef gpio;
    TIM_TimeBaseInitTypeDef time_base;
    TIM_OCInitTypeDef output_compare;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_TIM1,
                           ENABLE);

    gpio.GPIO_Pin = GPIO_Pin_8;
    gpio.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio);

    /* TIM1 counter frequency is 1 MHz, so one count equals one microsecond. */
    time_base.TIM_Prescaler = (uint16_t)(SystemCoreClock / 1000000U - 1U);
    time_base.TIM_CounterMode = TIM_CounterMode_Up;
    time_base.TIM_Period = 20000U - 1U;
    time_base.TIM_ClockDivision = TIM_CKD_DIV1;
    time_base.TIM_RepetitionCounter = 0U;
    TIM_TimeBaseInit(TIM1, &time_base);

    output_compare.TIM_OCMode = TIM_OCMode_PWM1;
    output_compare.TIM_OutputState = TIM_OutputState_Enable;
    output_compare.TIM_Pulse = SERVO_CENTER_US;
    output_compare.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OC1Init(TIM1, &output_compare);
    TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
    TIM_ARRPreloadConfig(TIM1, ENABLE);
    TIM_CtrlPWMOutputs(TIM1, ENABLE);
    TIM_Cmd(TIM1, ENABLE);
}

void Servo_SelectControlMode(uint8_t control_mode)
{
    if (control_mode == 2U) {
        g_servo_center_us = MODE2_SERVO_CENTER_US;
        g_servo_min_us = MODE2_SERVO_MIN_US;
        g_servo_max_us = MODE2_SERVO_MAX_US;
        g_servo_direction = MODE2_SERVO_CONTROL_DIRECTION;
    } else if (control_mode == 3U) {
        g_servo_center_us = MODE3_SERVO_CENTER_US;
        g_servo_min_us = MODE3_SERVO_MIN_US;
        g_servo_max_us = MODE3_SERVO_MAX_US;
        g_servo_direction = MODE3_SERVO_CONTROL_DIRECTION;
    } else {
        g_servo_center_us = SERVO_CENTER_US;
        g_servo_min_us = SERVO_MIN_US;
        g_servo_max_us = SERVO_MAX_US;
        g_servo_direction = SERVO_CONTROL_DIRECTION;
    }
    g_servo_us_per_deg = SERVO_US_PER_DEG;
    Servo_Center();
}

void Servo_SetPulseUs(int16_t pulse_us)
{
    if (pulse_us < g_servo_min_us) {
        pulse_us = g_servo_min_us;
    } else if (pulse_us > g_servo_max_us) {
        pulse_us = g_servo_max_us;
    }

    g_servo_pulse_us = pulse_us;
    TIM_SetCompare1(TIM1, (uint16_t)pulse_us);
}

void Servo_SetControl(float control_us)
{
    float pulse = (float)g_servo_center_us + g_servo_direction * control_us;
    Servo_SetPulseUs((int16_t)pulse);
}

void Servo_SetAngle(float angle_deg)
{
    Servo_SetControl(angle_deg * g_servo_us_per_deg);
}

void Servo_Center(void)
{
    Servo_SetPulseUs(g_servo_center_us);
}

int16_t Servo_GetPulseUs(void)
{
    return g_servo_pulse_us;
}
