#ifndef __SERVO_H
#define __SERVO_H

#include "stm32f10x.h"

void Servo_Init(void);
void Servo_SelectControlMode(uint8_t control_mode);
void Servo_SetPulseUs(int16_t pulse_us);
void Servo_SetControl(float control_us);
void Servo_SetAngle(float angle_deg);
void Servo_Center(void);
int16_t Servo_GetPulseUs(void);

#endif
