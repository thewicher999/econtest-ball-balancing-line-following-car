#include "stm32f10x.h"
#include "BallControl.h"
#include "K230Protocol.h"
#include "OLED.h"
#include "Servo.h"

int main(void)
{
	SystemCoreClockUpdate();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

	Servo_Init();
	K230Protocol_Init();
	BallControl_Init();
	/* Start the two-second delay as soon as the servo is centered. */
	SysTick_Config(SystemCoreClock / 1000U);
	OLED_Init();
	OLED_ShowControlState(BallControl_GetState());

	while (1)
	{
		BallControl_Process();
		OLED_ShowControlState(BallControl_GetState());
		__WFI();
	}
}
