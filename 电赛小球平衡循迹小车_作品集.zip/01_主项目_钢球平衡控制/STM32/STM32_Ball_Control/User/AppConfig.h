#ifndef __APP_CONFIG_H
#define __APP_CONFIG_H

/* ============================================================
 * Four main open-loop tuning parameters.
 * Angle is the tube angle relative to horizontal, in degrees.
 * Time is how long that angle is held, in milliseconds.
 * ============================================================ */
#define OPEN_LOOP_POSITIVE_ANGLE_DEG  (+20.0f)
#define OPEN_LOOP_POSITIVE_TIME_MS    750U
#define OPEN_LOOP_NEGATIVE_ANGLE_DEG  (-12.0f)
#define OPEN_LOOP_NEGATIVE_TIME_MS    700U

/* Return horizontal after open loop, then wait before enabling K230 PID. */
#define HORIZONTAL_WAIT_BEFORE_CLOSED_LOOP_MS  1000U

/* Final K230 closed-loop target and initial PID parameters. */
#define CLOSED_LOOP_TARGET_CM          (-6.0f)
#define CLOSED_LOOP_PERIOD_MS          10U
#define CLOSED_LOOP_KP                 30.0f
#define CLOSED_LOOP_KI                 1.0f
#define CLOSED_LOOP_KD                 16.0f
#define CLOSED_LOOP_INTEGRAL_LIMIT     35.0f
#define CLOSED_LOOP_MAX_CONTROL_US     160.0f
#define CLOSED_LOOP_SLEW_US_PER_CYCLE  12.0f
#define VELOCITY_FILTER_ALPHA          0.35f
#define MAX_MEASURED_SPEED_CM_S        80.0f
#define POSITION_VALID_MIN_CM          (-13.0f)
#define POSITION_VALID_MAX_CM          (+13.0f)

/* K230 IO9 TX -> STM32 PA10 / USART1_RX. */
#define K230_UART_BAUDRATE             115200U
#define K230_LINK_TIMEOUT_MS           300U

/* ============================================================
 * User parameters: normally only edit this file.
 * Target board: STM32F103C8T6, 72 MHz, StdPeriph Library V3.5.0
 * ============================================================ */

/* Keep the tube horizontal for two seconds after startup. */
#define OPEN_LOOP_START_DELAY_MS      2000U

/* Servo calibration: PWM change required for one tube-angle degree. */
#define SERVO_US_PER_DEG              10.0f

/* 4-pin SSD1306 128x64 OLED, software I2C: PB6=SCL, PB7=SDA. */
#define OLED_I2C_ADDRESS               0x3CU
#define OLED_GPIO                      GPIOB
#define OLED_GPIO_CLOCK                RCC_APB2Periph_GPIOB
#define OLED_SCL_PIN                   GPIO_Pin_6
#define OLED_SDA_PIN                   GPIO_Pin_7

/* SG90 PWM on PA8 / TIM1_CH1. Power the servo from a separate 5 V supply. */
#define SERVO_CENTER_US                1500
#define SERVO_MIN_US                   500
#define SERVO_MAX_US                   3000

/* Change to -1 if the ball moves away from the target after power-on. */
#define SERVO_CONTROL_DIRECTION        (+1.0f)

/* Mode 2 keeps the original 0 cm project servo calibration. */
#define MODE2_SERVO_CENTER_US           1520
#define MODE2_SERVO_MIN_US              1250
#define MODE2_SERVO_MAX_US              1650
#define MODE2_SERVO_CONTROL_DIRECTION   (+1.0f)

/* Mode 3 keeps the original arbitrary-position project calibration. */
#define MODE3_SERVO_CENTER_US           1520
#define MODE3_SERVO_MIN_US              1250
#define MODE3_SERVO_MAX_US              1700
#define MODE3_SERVO_CONTROL_DIRECTION   (+1.0f)

/* PC13 status LED is active-low on the common Blue Pill board. */
#define STATUS_LED_GPIO                GPIOC
#define STATUS_LED_PIN                 GPIO_Pin_13

#endif
