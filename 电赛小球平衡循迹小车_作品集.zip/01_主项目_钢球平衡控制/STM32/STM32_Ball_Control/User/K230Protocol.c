#include "K230Protocol.h"
#include "AppConfig.h"

#define FRAME_SIZE 8U

static volatile K230PositionFrame g_latest_frame;
static volatile uint8_t g_has_frame = 0U;
static uint8_t g_rx_buffer[FRAME_SIZE];
static uint8_t g_rx_index = 0U;

static uint8_t CalculateXor(const uint8_t *data, uint8_t length)
{
    uint8_t result = 0U;
    uint8_t i;

    for (i = 0U; i < length; ++i) {
        result ^= data[i];
    }
    return result;
}

void K230Protocol_Init(void)
{
    GPIO_InitTypeDef gpio;
    USART_InitTypeDef usart;
    NVIC_InitTypeDef nvic;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_USART1,
                           ENABLE);

    gpio.GPIO_Pin = GPIO_Pin_9;
    gpio.GPIO_Mode = GPIO_Mode_AF_PP;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &gpio);

    gpio.GPIO_Pin = GPIO_Pin_10;
    gpio.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA, &gpio);

    usart.USART_BaudRate = K230_UART_BAUDRATE;
    usart.USART_WordLength = USART_WordLength_8b;
    usart.USART_StopBits = USART_StopBits_1;
    usart.USART_Parity = USART_Parity_No;
    usart.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    usart.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
    USART_Init(USART1, &usart);

    USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);
    nvic.NVIC_IRQChannel = USART1_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 1U;
    nvic.NVIC_IRQChannelSubPriority = 0U;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);
    USART_Cmd(USART1, ENABLE);
}

void K230Protocol_OnRxByte(uint8_t byte, uint32_t now_ms)
{
    uint8_t flags;

    if (g_rx_index == 0U && byte != 0xAAU) {
        return;
    }
    if (g_rx_index == 1U && byte != 0x55U) {
        g_rx_index = (byte == 0xAAU) ? 1U : 0U;
        return;
    }

    g_rx_buffer[g_rx_index++] = byte;
    if (g_rx_index < FRAME_SIZE) {
        return;
    }
    g_rx_index = 0U;

    if (g_rx_buffer[7] != CalculateXor(g_rx_buffer, 7U)) {
        return;
    }

    flags = g_rx_buffer[6];
    g_latest_frame.position_mm = (int16_t)((uint16_t)g_rx_buffer[2] |
                                            ((uint16_t)g_rx_buffer[3] << 8));
    g_latest_frame.confidence_percent = g_rx_buffer[4];
    g_latest_frame.sequence = g_rx_buffer[5];
    g_latest_frame.valid = (flags & 0x01U) ? 1U : 0U;
    g_latest_frame.control_mode = (flags >> 4) & 0x03U;
    g_latest_frame.received_ms = now_ms;
    g_has_frame = 1U;
}

uint8_t K230Protocol_GetLatest(K230PositionFrame *frame)
{
    uint8_t available;

    __disable_irq();
    available = g_has_frame;
    if (available) {
        *frame = g_latest_frame;
    }
    __enable_irq();
    return available;
}
