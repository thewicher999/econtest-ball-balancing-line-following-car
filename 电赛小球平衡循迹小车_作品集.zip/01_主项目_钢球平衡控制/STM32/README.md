# STM32 KEY1三模式控制器

目标板：STM32F103C8T6，72 MHz，STM32F10x StdPeriph Library V3.5.0。

使用 Keil 打开 `STM32_Ball_Control/Project.uvprojx`，或直接烧录 `STM32_Ball_Control/Objects/Project.hex`。

已使用 ARMCC V5.06 update 5 实际编译：`0 Error(s), 0 Warning(s)`。

模式1主参数位于 `User/AppConfig.h`；模式2和模式3的 PID、学习和盲区救球参数位于 `User/BallControl.c` 顶部；三种模式各自的舵机中位和限位位于 `User/AppConfig.h`。
